﻿<?php
/**
 * Admin login page
 */
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>تسجيل دخول الإدارة - <?= e($siteTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            min-height: 100vh;
            margin: 0;
            font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            background: radial-gradient(circle at 20% 20%, rgba(96, 165, 250, 0.18), transparent 25%),
                        radial-gradient(circle at 80% 15%, rgba(236, 72, 153, 0.16), transparent 20%),
                        linear-gradient(180deg, #020617 0%, #111827 55%, #020617 100%);
            color: #f8fafc;
        }
        .login-screen {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1.5rem;
        }
        .login-card {
            width: 100%;
            max-width: 500px;
            border-radius: 1.35rem;
            background: rgba(15, 23, 42, 0.92);
            border: 1px solid rgba(148, 163, 184, 0.14);
            box-shadow: 0 32px 90px rgba(15, 23, 42, 0.28);
            overflow: hidden;
            backdrop-filter: blur(18px);
        }
        .login-card .card-body {
            padding: 2rem 2rem 1.5rem;
        }
        .login-card h1 {
            font-weight: 700;
            letter-spacing: 0.02em;
        }
        .login-card p {
            color: #cbd5e1;
        }
        .form-control {
            border-radius: 0.85rem;
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.12);
            color: #f8fafc;
        }
        .form-control:focus {
            border-color: rgba(59, 130, 246, 0.85);
            box-shadow: 0 0 0 0.2rem rgba(59, 130, 246, 0.18);
        }
        .btn-primary {
            border-radius: 0.95rem;
            padding: 0.95rem 1.2rem;
            font-weight: 600;
            box-shadow: 0 18px 36px rgba(37, 99, 235, 0.18);
        }
        .auth-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            color: #93c5fd;
            margin-bottom: 1rem;
            font-size: 0.95rem;
        }
        .auth-badge .bi {
            font-size: 1.1rem;
        }
        .login-footer {
            margin-top: 1.75rem;
            text-align: center;
            color: #94a3b8;
            font-size: 0.92rem;
        }
        .login-footer code {
            background: rgba(148, 163, 184, 0.16);
            padding: 0.16rem 0.35rem;
            border-radius: 0.4rem;
            font-size: 0.92rem;
            color: #e2e8f0;
        }
    </style>
</head>
<body>
<div class="login-screen">
    <div class="card login-card">
        <div class="card-body">
            <div class="auth-badge"><i class="bi bi-shield-lock-fill"></i> دخول آمن لصفحة الإدارة</div>
            <h1 class="h3 mb-2 text-center">لوحة تحكم <?= e($siteTitle) ?></h1>
            <p class="text-center mb-4">أدخل كلمة المرور للوصول إلى إعدادات النشر، مصادر المحتوى، والتحكم في أداء الموقع.</p>

            <?php if (!empty($loginError)): ?>
                <div class="alert alert-danger py-2 mb-3" role="alert"><?= e($loginError) ?></div>
            <?php endif; ?>
            <?php if (!empty($isLocked)): ?>
                <div class="alert alert-warning py-2 mb-3" role="alert">عدد محاولات الدخول وصل للحد. الرجاء المحاولة بعد <?= (int)$remainingLockSeconds ?> ثانية.</div>
            <?php endif; ?>

            <form method="post" autocomplete="off" novalidate>
                <div class="mb-3">
                    <label for="pass" class="form-label">كلمة السر</label>
                    <input id="pass" type="password" name="pass" class="form-control form-control-lg" placeholder="اكتب كلمة المرور هنا" autocomplete="current-password" required autofocus>
                </div>
                <button type="submit" class="btn btn-primary w-100">تسجيل الدخول</button>
            </form>

            <div class="login-footer">نصيحة: استخدم متغير البيئة <code>ADMIN_PASSWORD</code> لتأمين الدخول في بيئة الإنتاج.</div>
        </div>
    </div>
</div>
</body>
</html>

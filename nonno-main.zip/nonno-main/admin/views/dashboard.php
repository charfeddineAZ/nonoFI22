﻿<?php
/**
 * Admin Dashboard Main View
 * Renders the complete admin interface
 */
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>لوحة الإدارة - <?= e($siteTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            min-height: 100vh;
            font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            color: #f8fafc;
            background: radial-gradient(circle at 10% 10%, rgba(59, 130, 246, 0.18), transparent 25%),
                        radial-gradient(circle at 90% 15%, rgba(168, 85, 247, 0.14), transparent 20%),
                        linear-gradient(155deg, #020617 0%, #0b1120 35%, #111827 100%);
        }
        .container {
            max-width: 1320px;
        }
        .page-header {
            border-radius: 1rem;
            background: rgba(15, 23, 42, 0.94);
            border: 1px solid rgba(148, 163, 184, 0.18);
            box-shadow: 0 28px 70px rgba(15, 23, 42, 0.18);
        }
        .page-header .badge {
            letter-spacing: 0.04em;
        }
        .card.section-card {
            border-radius: 1rem;
            background: rgba(15, 23, 42, 0.95);
            border: 1px solid rgba(148, 163, 184, 0.18);
            box-shadow: 0 20px 45px rgba(15, 23, 42, 0.12);
        }
        .section-card .card-body {
            min-height: 240px;
        }
        .card h5,
        .card h6 {
            color: #ffffff;
        }
        .text-muted,
        .text-secondary,
        small {
            color: #94a3b8 !important;
        }
        .stat-card h2 {
            margin-bottom: 0.35rem;
            font-weight: 700;
        }
        .stat-card p {
            margin-bottom: 0;
        }
        .list-group-item {
            background: rgba(15, 23, 42, 0.9);
            border-color: rgba(148, 163, 184, 0.12);
            color: #f8fafc;
        }
        .table {
            color: #f8fafc;
        }
        .table thead th {
            border-bottom-color: rgba(148, 163, 184, 0.22);
        }
        .table tbody tr:hover {
            background: rgba(255, 255, 255, 0.04);
        }
        .badge-soft {
            background: rgba(15, 23, 42, 0.8);
            color: #f8fafc;
        }
        .hero-metrics .card {
            min-height: 190px;
        }
        .hero-toolbar {
            gap: 0.75rem;
            flex-wrap: wrap;
        }
        .hero-toolbar .btn {
            min-height: 46px;
        }
        @media (max-width: 991.98px) {
            .container {
                padding-left: 1rem;
                padding-right: 1rem;
            }
            .hero-metrics .card {
                min-height: 170px;
            }
            .page-header {
                padding: 1.2rem 1.25rem;
            }
        }
    </style>
</head>
<body>
<div class="container py-4 py-lg-5">
    <div class="page-header p-4 p-lg-5 mb-4">
        <div class="d-flex flex-column flex-lg-row align-items-start align-items-lg-center justify-content-between gap-3">
            <div>
                <span class="badge bg-primary mb-3 px-3 py-2"><i class="bi bi-speedometer2"></i> لوحة التحكم</span>
                <h1 class="h3 mb-2"><?= e($siteTitle) ?></h1>
                <p class="mb-0 text-secondary">واجهة إدارة حديثة للمحتوى، مصادر RSS/Web، إعدادات SEO، وجدولة النشر.</p>
            </div>
            <div class="d-flex hero-toolbar">
                <a href="index.php" target="_blank" class="btn btn-outline-light"><i class="bi bi-box-arrow-up-right"></i> عرض الموقع</a>
                <form method="post" class="mb-0">
                    <input type="hidden" name="csrf_token" value="<?= e($csrf) ?>">
                    <button type="submit" name="logout" value="1" class="btn btn-danger"><i class="bi bi-box-arrow-right"></i> خروج</button>
                </form>
            </div>
        </div>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert alert-<?= e($messageType) ?> alert-dismissible fade show mb-4" role="alert">
            <?= e($message) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row g-4 mb-4 hero-metrics">
        <div class="col-sm-6 col-xl-3">
            <div class="card section-card p-4">
                <h6 class="text-uppercase text-secondary mb-3">مقالات</h6>
                <h2 class="text-white"><?= (int)$totalArticles ?></h2>
                <p class="text-muted mb-0">إجمالي المقالات المنشورة.</p>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="card section-card p-4">
                <h6 class="text-uppercase text-secondary mb-3">مصادر RSS</h6>
                <h2 class="text-white"><?= (int)$totalSources ?></h2>
                <p class="text-muted mb-0">مصادر الاعتماد العالمية.</p>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="card section-card p-4">
                <h6 class="text-uppercase text-secondary mb-3">مصادر الويب</h6>
                <h2 class="text-white"><?= (int)$totalWebSources ?></h2>
                <p class="text-muted mb-0">مصادر الويب المسجلة.</p>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="card section-card p-4">
                <h6 class="text-uppercase text-secondary mb-3">الحد اليومي</h6>
                <h2 class="text-white"><?= (int)$dailyLimit ?></h2>
                <p class="text-muted mb-0">عدد المقالات اليومية المسموح بها.</p>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-lg-8">
            <div class="card section-card">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <div>
                            <h5 class="mb-1">أحدث المقالات</h5>
                            <p class="text-secondary mb-0">أحدث 5 مقالات من قاعدة البيانات.</p>
                        </div>
                        <small class="text-muted">آخر تحديث: <?= e($latestDate ?: 'N/A') ?></small>
                    </div>
                    <?php if (!empty($articles)): ?>
                        <div class="table-responsive">
                            <table class="table table-borderless align-middle mb-0">
                                <thead>
                                    <tr class="text-secondary small text-uppercase">
                                        <th>العنوان</th>
                                        <th>الفئة</th>
                                        <th>تاريخ النشر</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach (array_slice($articles, 0, 5) as $article): ?>
                                        <tr>
                                            <td><?= e($article['title']) ?></td>
                                            <td><?= e($article['category'] ?: 'عام') ?></td>
                                            <td><?= e($article['published_at'] ?: 'غير محدد') ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-secondary mb-0">لا توجد مقالات لعرضها بعد.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card section-card h-100">
                <div class="card-body">
                    <h5 class="mb-3">ملخص التكوين</h5>
                    <dl class="row text-secondary mb-0">
                        <dt class="col-7">إعدادات عامة</dt>
                        <dd class="col-5 text-end"><?= (int)$configGlobalSettingsCount ?></dd>
                        <dt class="col-7">عدد النيتش</dt>
                        <dd class="col-5 text-end"><?= (int)$configNichesCount ?></dd>
                        <dt class="col-7">مصادر RSS</dt>
                        <dd class="col-5 text-end"><?= (int)$configGlobalRssCount ?></dd>
                        <dt class="col-7">مصادر الويب</dt>
                        <dd class="col-5 text-end"><?= (int)$configGlobalWebCount ?></dd>
                        <dt class="col-7">زوار متعقّبون</dt>
                        <dd class="col-5 text-end"><?= (int)$totalTrackedVisitors ?></dd>
                        <dt class="col-7">إجمالي المشاهدات</dt>
                        <dd class="col-5 text-end"><?= (int)$totalTrackedViews ?></dd>
                    </dl>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-6">
            <div class="card section-card">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <h5 class="mb-0">أحدث مصادر RSS</h5>
                        <span class="badge bg-secondary badge-soft"><?= count($rssRows) ?></span>
                    </div>
                    <?php if (!empty($rssRows)): ?>
                        <ul class="list-group list-group-flush">
                            <?php foreach (array_slice($rssRows, 0, 6) as $row): ?>
                                <li class="list-group-item text-truncate" title="<?= e($row['url']) ?>"><?= e($row['url']) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <div class="alert alert-secondary mb-0">لا توجد مصادر RSS حتى الآن.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card section-card">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <h5 class="mb-0">أحدث مصادر الويب</h5>
                        <span class="badge bg-secondary badge-soft"><?= count($webRows) ?></span>
                    </div>
                    <?php if (!empty($webRows)): ?>
                        <ul class="list-group list-group-flush">
                            <?php foreach (array_slice($webRows, 0, 6) as $row): ?>
                                <li class="list-group-item text-truncate" title="<?= e($row['url']) ?>"><?= e($row['url']) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <div class="alert alert-secondary mb-0">لا توجد مصادر ويب حتى الآن.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

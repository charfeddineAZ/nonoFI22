<?php

function getTags() {
    $pdo = db_connect();
    $stmt = $pdo->prepare("SELECT id, name, slug, description, post_count FROM tags ORDER BY post_count DESC");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function addTagToArticle($articleId, $tagName) {
    $pdo = db_connect();
    $slug = preg_replace('/[^a-z0-9]+/', '-', strtolower($tagName));

    $pdo->prepare("INSERT OR IGNORE INTO tags (name, slug, description) VALUES (?, ?, ?)")
        ->execute([$tagName, $slug, '']);

    $tagStmt = $pdo->prepare("SELECT id FROM tags WHERE slug = ? LIMIT 1");
    $tagStmt->execute([$slug]);
    $tagId = (int)$tagStmt->fetchColumn();

    if ($tagId > 0) {
        $pdo->prepare("INSERT OR IGNORE INTO article_tags (article_id, tag_id) VALUES (?, ?)")
            ->execute([(int)$articleId, $tagId]);

        $pdo->prepare("UPDATE tags SET post_count = post_count + 1 WHERE id = ? AND post_count = (SELECT COUNT(*) - 1 FROM article_tags WHERE tag_id = ?)")
            ->execute([$tagId, $tagId]);
    }
}

function getArticleTags($articleId) {
    $pdo = db_connect();
    $stmt = $pdo->prepare("SELECT t.id, t.name, t.slug FROM tags t JOIN article_tags at ON t.id = at.tag_id WHERE at.article_id = ? ORDER BY t.name");
    $stmt->execute([(int)$articleId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function getArticlesForTag($tagSlug, $limit = 12) {
    $pdo = db_connect();
    $stmt = $pdo->prepare(""
        SELECT a.id, a.title, a.slug, a.excerpt, a.image, a.image2, a.translated_title, a.published_at 
        FROM articles a
        JOIN article_tags at ON a.id = at.article_id
        JOIN tags t ON at.tag_id = t.id
        WHERE t.slug = ?
        ORDER BY a.published_at DESC
        LIMIT ?
    """);
    $stmt->execute([$tagSlug, (int)$limit]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function initArticleStats($articleId) {
    $pdo = db_connect();
    $pdo->prepare("INSERT OR IGNORE INTO article_stats (article_id, updated_at) VALUES (?, ?)")
        ->execute([(int)$articleId, time()]);
}

function generateAutoTags($title, $content = '') {
    $text = mb_strtolower($title . ' ' . strip_tags($content), 'UTF-8');
    $stop = ['the','and','for','with','this','that','from','your','have','will','2026','best','new','review'];
    preg_match_all('/\b[a-z0-9]{4,}\b/', $text, $matches);
    $counts = array_count_values($matches[0]);
    arsort($counts);
    $tags = [];
    foreach ($counts as $word => $cnt) {
        if (in_array($word, $stop, true)) continue;
        $tags[] = ucfirst($word);
        if (count($tags) >= 5) break;
    }
    return $tags;
}

function translateText($text, $targetLang = 'ar') {
    $text = trim((string)$text);
    $targetLang = trim((string)$targetLang);
    if ($text === '' || $targetLang === '') {
        return '';
    }
    $url = 'https://api.mymemory.translated.net/get?q=' . rawurlencode($text) . '&langpair=en|' . rawurlencode($targetLang);
    $resp = @file_get_contents($url);
    if (!$resp) {
        return '';
    }
    $data = json_decode($resp, true);
    return $data['responseData']['translatedText'] ?? '';
}

function recordArticleView($articleId) {
    $pdo = db_connect();
    $pdo->prepare("UPDATE article_stats SET views = views + 1, updated_at = ? WHERE article_id = ?")
        ->execute([time(), (int)$articleId]);
}

function rateArticle($articleId, $rating, $visitorHash = '') {
    if ($rating < 1 || $rating > 5) return false;

    $pdo = db_connect();
    $visitorHash = $visitorHash ?: getVisitorFingerprint();

    $pdo->prepare("INSERT OR REPLACE INTO article_ratings (article_id, rating, visitor_hash, created_at) VALUES (?, ?, ?, ?)")
        ->execute([(int)$articleId, (int)$rating, $visitorHash, time()]);

    $avgStmt = $pdo->prepare("SELECT AVG(rating) as avg, COUNT(*) as count FROM article_ratings WHERE article_id = ?");
    $avgStmt->execute([(int)$articleId]);
    $row = $avgStmt->fetch(PDO::FETCH_ASSOC);

    $pdo->prepare("UPDATE article_stats SET avg_rating = ?, rating_count = ?, updated_at = ? WHERE article_id = ?")
        ->execute([round($row['avg'], 1), (int)$row['count'], time(), (int)$articleId]);

    return true;
}

function getArticleStats($articleId) {
    $pdo = db_connect();
    $stmt = $pdo->prepare("SELECT views, clicks, avg_rating, rating_count, shares FROM article_stats WHERE article_id = ? LIMIT 1");
    $stmt->execute([(int)$articleId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: [
        'views' => 0,
        'clicks' => 0,
        'avg_rating' => 0,
        'rating_count' => 0,
        'shares' => 0,
    ];
}

function getTrendingArticles($limit = 10) {
    $pdo = db_connect();
    $stmt = $pdo->prepare(""
        SELECT a.id, a.title, a.slug, a.excerpt, a.image, a.published_at,
               a.image2, a.translated_title,
               s.views, s.avg_rating, s.rating_count
        FROM articles a
        LEFT JOIN article_stats s ON a.id = s.article_id
        ORDER BY COALESCE(s.views, 0) DESC
        LIMIT ?
    """);
    $stmt->execute([(int)$limit]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function getTopRatedArticles($limit = 10) {
    $pdo = db_connect();
    $stmt = $pdo->prepare(""
        SELECT a.id, a.title, a.slug, a.excerpt, a.image, a.published_at,
               s.views, s.avg_rating, s.rating_count
        FROM articles a
        LEFT JOIN article_stats s ON a.id = s.article_id
        WHERE s.avg_rating > 0 AND s.rating_count > 0
        ORDER BY s.avg_rating DESC, s.rating_count DESC
        LIMIT ?
    """);
    $stmt->execute([(int)$limit]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function normalizeTextForComparison($text) {
    $text = mb_strtolower((string)$text, 'UTF-8');
    $text = preg_replace('/\s+/u', ' ', $text);
    return trim((string)$text);
}

function normalizeTitleFingerprint($title) {
    $title = cleanAndNormalizeTitle($title);
    if ($title === '') {
        return '';
    }

    $title = mb_strtolower($title, 'UTF-8');
    $title = preg_replace('/\b(19|20)\d{2}\b/u', ' ', (string)$title);
    $title = preg_replace('/[^\p{L}\p{N}]+/u', ' ', (string)$title);

    $tokens = preg_split('/\s+/u', trim((string)$title));
    if (!is_array($tokens)) {
        return '';
    }

    $stopWords = [
        'the', 'a', 'an', 'and', 'or', 'for', 'with', 'from', 'to', 'of',
        'review', 'guide', 'buying', 'best', 'top', 'new', 'vs'
    ];

    $filtered = [];
    foreach ($tokens as $token) {
        if ($token === '' || in_array($token, $stopWords, true)) {
            continue;
        }
        $filtered[] = $token;
    }

    return implode(' ', $filtered);
}

function articleTitleVariantExists($title) {
    $pdo = db_connect();
    $baseSlug = slugify($title);
    if ($baseSlug === '') {
        return false;
    }

    $stmt = $pdo->prepare("SELECT 1 FROM articles WHERE slug = ? OR slug LIKE ? LIMIT 1");
    $stmt->execute([$baseSlug, $baseSlug . '-%']);
    return $stmt->fetchColumn() !== false;
}

function articleTitleFingerprintExists($title) {
    $fingerprint = normalizeTitleFingerprint($title);
    if ($fingerprint === '') {
        return false;
    }

    $pdo = db_connect();
    $rowsStmt = $pdo->prepare("SELECT title FROM articles ORDER BY id DESC LIMIT 500");
    $rowsStmt->execute();
    $rows = $rowsStmt->fetchAll(PDO::FETCH_COLUMN);
    foreach ($rows as $storedTitle) {
        $storedFingerprint = normalizeTitleFingerprint((string)$storedTitle);
        if ($storedFingerprint !== '' && hash_equals($storedFingerprint, $fingerprint)) {
            return true;
        }
    }

    return false;
}

function articleContentExists($content) {
    $normalizedContent = normalizeTextForComparison(strip_tags((string)$content));
    if ($normalizedContent === '') {
        return false;
    }

    $pdo = db_connect();
    $stmt = $pdo->prepare("SELECT content FROM articles ORDER BY id DESC LIMIT 200");
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_COLUMN);

    foreach ($rows as $storedContent) {
        $storedNormalized = normalizeTextForComparison(strip_tags((string)$storedContent));
        if ($storedNormalized !== '' && hash_equals($storedNormalized, $normalizedContent)) {
            return true;
        }
    }

    return false;
}

function isDuplicateArticlePayload($title, $content) {
    return articleExists($title)
        || articleTitleVariantExists($title)
        || articleTitleFingerprintExists($title)
        || articleContentExists($content);
}

function generateUniqueSlug($title) {
    $pdo = db_connect();
    $base = slugify($title);
    $base = $base !== '' ? $base : 'article';
    $slug = $base;
    $i = 2;

    while (true) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM articles WHERE slug = ?");
        $stmt->execute([$slug]);
        if ((int)$stmt->fetchColumn() === 0) {
            return $slug;
        }
        $slug = $base . '-' . $i;
        $i++;
    }
}

function buildFreeArticleImageUrl($seed, $nicheSlug = '') {
    $seedText = trim((string)$seed);
    if ($seedText === '') {
        $seedText = 'car-article';
    }

    if ($nicheSlug === '') {
        $nicheSlug = getActiveNicheSlug();
    }
    $nicheSlug = trim((string)$nicheSlug);
    if ($nicheSlug === '') {
        $nicheSlug = 'general';
    }

    $slug = preg_replace('/[^a-z0-9]+/i', '-', strtolower($seedText . '-' . $nicheSlug));
    $slug = trim((string)$slug, '-');
    if ($slug === '') {
        $slug = 'car-article-general';
    }

    return "https://picsum.photos/seed/{$slug}/1200/675";
}

function buildUniqueArticleImageUrl($title, $model = '') {
    $pdo = db_connect();
    $baseSeed = trim($title . '-' . $model);
    $activeNiche = getActiveNicheSlug();

    for ($attempt = 1; $attempt <= 20; $attempt++) {
        $seed = $attempt === 1 ? $baseSeed : $baseSeed . '-' . $attempt;
        $candidate = buildFreeArticleImageUrl($seed, $activeNiche);
        $stmt = $pdo->prepare("SELECT 1 FROM articles WHERE image = ? LIMIT 1");
        $stmt->execute([$candidate]);
        if ($stmt->fetchColumn() === false) {
            return $candidate;
        }
    }

    return buildFreeArticleImageUrl($baseSeed . '-' . uniqid('', true), $activeNiche);
}

function verifyAdminPassword($password) {
    if (!is_string($password) || $password === '') {
        return false;
    }

    $adminPassword = getenv('ADMIN_PASSWORD');
    if (is_string($adminPassword) && $adminPassword !== '' && hash_equals($adminPassword, $password)) {
        return true;
    }

    $storedHash = getSetting('admin_password_hash', PASSWORD_HASH);
    if (!is_string($storedHash) || trim($storedHash) === '') {
        $storedHash = PASSWORD_HASH;
    }

    return password_verify($password, $storedHash);
}

function estimateReadingTime($htmlContent) {
    $wordCount = str_word_count(strip_tags($htmlContent));
    return max(1, (int)ceil($wordCount / 220));
}

function csrfToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && is_string($token) && hash_equals($_SESSION['csrf_token'], $token);
}

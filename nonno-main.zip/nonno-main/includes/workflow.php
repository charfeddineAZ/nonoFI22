<?php

function getSelectedContentWorkflow() {
    $allowed = ['rss', 'web'];
    $workflow = trim((string)getSetting('content_workflow', 'rss'));
    return in_array($workflow, $allowed, true) ? $workflow : 'rss';
}

function enqueueWorkflowSources($workflow, array $sources) {
    $workflow = $workflow === 'web' ? 'web' : 'rss';
    $pdo = db_connect();
    $now = time();

    $existsStmt = $pdo->prepare('SELECT id FROM scrape_queue WHERE workflow = ? AND source_url = ? AND status IN ("pending","processing") LIMIT 1');
    $insertStmt = $pdo->prepare('INSERT INTO scrape_queue (workflow, source_url, status, attempts, locked_until, available_at, created_at, updated_at) VALUES (?, ?, "pending", 0, 0, ?, ?, ?)');

    foreach ($sources as $sourceUrl) {
        $sourceUrl = trim((string)$sourceUrl);
        if ($sourceUrl === '') {
            continue;
        }

        $existsStmt->execute([$workflow, $sourceUrl]);
        if ($existsStmt->fetchColumn() !== false) {
            continue;
        }

        $insertStmt->execute([$workflow, $sourceUrl, $now, $now, $now]);
    }
}

function pullWorkflowQueueItems($workflow, $limit) {
    $workflow = $workflow === 'web' ? 'web' : 'rss';
    $limit = max(1, (int)$limit);
    $pdo = db_connect();
    $now = time();
    $sourceCooldown = getSettingInt('queue_source_cooldown_seconds', 180, 30, 7200);

    resetStaleQueueLocks($workflow);

    $sql = 'SELECT id, source_url
        FROM scrape_queue
        WHERE workflow = ?
          AND status = "pending"
          AND available_at <= ?
          AND locked_until <= ?
          AND source_url NOT IN (
              SELECT source_url
              FROM scrape_queue
              WHERE workflow = ?
                AND status IN ("done", "processing")
                AND updated_at >= ?
          )
        ORDER BY id ASC
        LIMIT ' . $limit;
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$workflow, $now, $now, $workflow, $now - $sourceCooldown]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $lockUntil = $now + 120;
    $lockStmt = $pdo->prepare('UPDATE scrape_queue SET status = "processing", locked_until = ?, updated_at = ? WHERE id = ?');
    foreach ($items as $item) {
        $lockStmt->execute([$lockUntil, $now, (int)$item['id']]);
    }

    return $items;
}

function resetStaleQueueLocks($workflow) {
    $workflow = $workflow === 'web' ? 'web' : 'rss';
    $pdo = db_connect();
    $now = time();

    $stmt = $pdo->prepare('UPDATE scrape_queue
        SET status = "pending", locked_until = 0, updated_at = ?
        WHERE workflow = ? AND status = "processing" AND locked_until > 0 AND locked_until <= ?');
    $stmt->execute([$now, $workflow, $now]);
}

function markQueueItemDone($id) {
    $pdo = db_connect();
    $stmt = $pdo->prepare('UPDATE scrape_queue SET status = "done", locked_until = 0, updated_at = ? WHERE id = ?');
    $stmt->execute([time(), (int)$id]);
}

function markQueueItemForRetry($id) {
    $pdo = db_connect();
    $retryDelay = getSettingInt('queue_retry_delay_seconds', 60, 10, 3600);
    $maxAttempts = getSettingInt('queue_max_attempts', 3, 1, 10);
    $now = time();

    $stmt = $pdo->prepare('SELECT attempts FROM scrape_queue WHERE id = ? LIMIT 1');
    $stmt->execute([(int)$id]);
    $attempts = (int)$stmt->fetchColumn() + 1;

    if ($attempts >= $maxAttempts) {
        $failStmt = $pdo->prepare('UPDATE scrape_queue SET status = "failed", attempts = ?, locked_until = 0, updated_at = ? WHERE id = ?');
        $failStmt->execute([$attempts, $now, (int)$id]);
        return;
    }

    $retryAt = $now + ($retryDelay * $attempts);
    $retryStmt = $pdo->prepare('UPDATE scrape_queue SET status = "pending", attempts = ?, available_at = ?, locked_until = 0, updated_at = ? WHERE id = ?');
    $retryStmt->execute([$attempts, $retryAt, $now, (int)$id]);
}

function cleanAndNormalizeTitle($title) {
    $title = html_entity_decode((string)$title, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $title = preg_replace('/\s+/u', ' ', $title);
    $title = preg_replace('/[\x00-\x1F\x7F]/u', '', (string)$title);
    $title = trim((string)$title);
    if (mb_strlen($title) < 5) {
        return '';
    }
    return $title;
}

function mergeAndDeduplicateTitles(array ...$collections) {
    $merged = [];
    foreach ($collections as $titles) {
        foreach ($titles as $title) {
            $clean = cleanAndNormalizeTitle($title);
            if ($clean === '') {
                continue;
            }
            $key = normalizeTextForComparison($clean);
            if (!isset($merged[$key])) {
                $merged[$key] = $clean;
            }
        }
    }
    return array_values($merged);
}

function runRssWorkflow($limit = null) {
    $pdo = db_connect();
    $nicheId = getActiveNicheId();
    $activeNiche = getActiveNicheSlug();

    $stmt = $pdo->prepare("SELECT url FROM niche_sources WHERE niche_id = ? AND type = 'rss' ORDER BY id DESC");
    $stmt->execute([$nicheId]);
    $sources = $stmt->fetchAll(PDO::FETCH_COLUMN) ?: [];
    if (empty($sources)) {
        $sources = getNicheRssSources($activeNiche) ?: [];
    }

    $limit = $limit === null ? max(1, (int)getSetting('daily_limit', 5)) : max(1, (int)$limit);
    $batchSize = getSettingInt('workflow_batch_size', 8, 1, 30);

    enqueueWorkflowSources('rss', $sources);
    $queueItems = pullWorkflowQueueItems('rss', $batchSize);

    $count = 0;
    $sourceStats = [];

    foreach ($queueItems as $queueItem) {
        $url = (string)$queueItem['source_url'];
        if ($count >= $limit) {
            break;
        }

        $titles = extractFeedTitles($url, max(10, $limit * 3));
        if (!$titles) {
            markQueueItemForRetry((int)$queueItem['id']);
            continue;
        }

        $publishedFromSource = 0;

        foreach ($titles as $title) {
            if ($count >= $limit) {
                break;
            }

            if ($title !== '' && !articleExists($title)) {
                $data = generateArticle($title);
                if (saveArticle($title, $data)) {
                    $count++;
                    $publishedFromSource++;
                }
            }
        }

        $sourceStats[] = [
            'url' => $url,
            'fetched_titles' => count($titles),
            'published' => $publishedFromSource,
        ];

        markQueueItemDone((int)$queueItem['id']);
    }

    return [
        'workflow' => 'rss',
        'sources_count' => count($sources),
        'queue_batch' => count($queueItems),
        'published' => $count,
        'stats' => $sourceStats,
    ];
}

function runWebWorkflow($limit = null) {
    $activeNiche = getActiveNicheSlug();
    $sources = getNicheWebSources($activeNiche) ?: [];
    $limit = $limit === null ? max(1, (int)getSetting('daily_limit', 5)) : max(1, (int)$limit);
    $batchSize = getSettingInt('workflow_batch_size', 8, 1, 30);

    enqueueWorkflowSources('web', $sources);
    $queueItems = pullWorkflowQueueItems('web', $batchSize);

    $count = 0;
    $sourceStats = [];

    foreach ($queueItems as $queueItem) {
        $url = (string)$queueItem['source_url'];
        if ($count >= $limit) {
            break;
        }

        $titles = extractTitlesFromNormalPage($url, max(10, $limit * 3));
        if (!$titles) {
            markQueueItemForRetry((int)$queueItem['id']);
            continue;
        }

        $publishedFromSource = 0;

        foreach ($titles as $title) {
            if ($count >= $limit) {
                break;
            }

            if ($title !== '' && !articleExists($title)) {
                $data = generateArticle($title);
                if (saveArticle($title, $data)) {
                    $count++;
                    $publishedFromSource++;
                }
            }
        }

        $sourceStats[] = [
            'url' => $url,
            'fetched_titles' => count($titles),
            'published' => $publishedFromSource,
        ];

        markQueueItemDone((int)$queueItem['id']);
    }

    return [
        'workflow' => 'web',
        'sources_count' => count($sources),
        'queue_batch' => count($queueItems),
        'published' => $count,
        'stats' => $sourceStats,
    ];
}

function runSelectedContentWorkflow($limit = null) {
    $selected = getSelectedContentWorkflow();
    if ($selected === 'web') {
        return runWebWorkflow($limit);
    }

    return runRssWorkflow($limit);
}

function getContentWorkflowSummary() {
    $pdo = db_connect();
    $selected = getSelectedContentWorkflow();
    $rssSourcesStmt = $pdo->prepare("SELECT COUNT(*) FROM rss_sources");
    $rssSourcesStmt->execute();
    $rssSources = (int)$rssSourcesStmt->fetchColumn();
    $webSourcesStmt = $pdo->prepare("SELECT COUNT(*) FROM web_sources");
    $webSourcesStmt->execute();
    $webSources = (int)$webSourcesStmt->fetchColumn();
    $dailyLimit = getSettingInt('daily_limit', 5, 1, 200);

    $selectedSources = $selected === 'web' ? $webSources : $rssSources;
    $scheduler = getAutoPublishSchedulerMeta();

    $health = 'ready';
    if ($selectedSources <= 0) {
        $health = 'missing_sources';
    } elseif (getSettingInt('auto_ai_enabled', 1, 0, 1) === 0) {
        $health = 'scheduler_disabled';
    }

    return [
        'selected_workflow' => $selected,
        'selected_workflow_label' => $selected === 'web' ? 'Normal Sites Workflow' : 'RSS Workflow',
        'rss_sources' => $rssSources,
        'web_sources' => $webSources,
        'selected_sources' => $selectedSources,
        'daily_limit' => $dailyLimit,
        'auto_ai_enabled' => getSettingInt('auto_ai_enabled', 1, 0, 1) === 1,
        'scheduler' => $scheduler,
        'health' => $health,
    ];
}

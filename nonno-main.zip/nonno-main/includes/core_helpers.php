<?php

use App\Utils;

function slugify($text) {
    return Utils::slugify((string)$text);
}

function e($text) {
    return Utils::e((string)$text);
}

function detectPreferredLanguage() {
    return Utils::detectPreferredLanguage();
}

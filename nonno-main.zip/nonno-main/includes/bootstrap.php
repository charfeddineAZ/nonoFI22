<?php

require_once __DIR__ . '/../config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$composerAutoload = __DIR__ . '/../vendor/autoload.php';
if (is_file($composerAutoload)) {
    require_once $composerAutoload;
}

require_once __DIR__ . '/polyfills.php';
require_once __DIR__ . '/core_helpers.php';
require_once __DIR__ . '/niche.php';
require_once __DIR__ . '/settings.php';
require_once __DIR__ . '/article_helpers.php';
require_once __DIR__ . '/visitor_tracking.php';
require_once __DIR__ . '/fetch_cache.php';
require_once __DIR__ . '/source_extraction.php';
require_once __DIR__ . '/workflow.php';
require_once __DIR__ . '/seo_ads.php';

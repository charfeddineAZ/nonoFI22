<?php

function extractFeedTitlesWithSymfonyCrawler($xmlString, $limit = 50) {
    if (!class_exists('Symfony\\Component\\DomCrawler\\Crawler')) {
        return [];
    }

    $limit = max(1, (int)$limit);
    $crawler = new Symfony\Component\DomCrawler\Crawler();

    try {
        $crawler->addXmlContent($xmlString, 'UTF-8');
    } catch (Throwable $e) {
        return [];
    }

    $selectors = [
        'channel > item > title',
        'feed > entry > title',
        'rdf\\:RDF > item > title',
        'item > title',
        'entry > title',
    ];

    $titles = [];
    foreach ($selectors as $selector) {
        $nodes = $crawler->filter($selector);
        if ($nodes->count() === 0) {
            continue;
        }

        foreach ($nodes as $node) {
            $title = trim((string)$node->textContent);
            if ($title !== '') {
                $titles[] = $title;
            }
            if (count($titles) >= $limit) {
                break 2;
            }
        }
    }

    return mergeAndDeduplicateTitles($titles);
}

function extractFeedTitlesWithSimpleXml($xmlString, $limit = 50) {
    $limit = max(1, (int)$limit);
    $xml = @simplexml_load_string($xmlString);
    if (!$xml) {
        return [];
    }

    $titles = [];

    if (isset($xml->channel->item)) {
        foreach ($xml->channel->item as $item) {
            $title = trim((string)$item->title);
            if ($title !== '') {
                $titles[] = $title;
            }
            if (count($titles) >= $limit) {
                break;
            }
        }
    }

    if (count($titles) < $limit && isset($xml->entry)) {
        foreach ($xml->entry as $entry) {
            $title = trim((string)$entry->title);
            if ($title !== '') {
                $titles[] = $title;
            }
            if (count($titles) >= $limit) {
                break;
            }
        }
    }

    return mergeAndDeduplicateTitles($titles);
}

function extractFeedTitles($url, $limit = 50) {
    $xmlString = fetchUrlBody($url);
    if (!is_string($xmlString) || trim($xmlString) === '') {
        return [];
    }

    $titles = extractFeedTitlesWithSymfonyCrawler($xmlString, $limit);
    if ($titles) {
        return $titles;
    }

    return extractFeedTitlesWithSimpleXml($xmlString, $limit);
}

function extractTitlesFromNormalPageWithSymfonyCrawler($htmlString, $limit = 50) {
    if (!class_exists('Symfony\Component\DomCrawler\Crawler')) {
        return [];
    }

    $limit = max(1, (int)$limit);
    $crawler = new Symfony\Component\DomCrawler\Crawler();

    try {
        $crawler->addHtmlContent($htmlString, 'UTF-8');
    } catch (Throwable $e) {
        return [];
    }

    $selectors = [
        'article h1 a, article h2 a, article h3 a',
        'main h1 a, main h2 a, main h3 a',
        '.post-title a, .entry-title a',
        'h1 a, h2 a, h3 a',
    ];

    $titles = [];
    foreach ($selectors as $selector) {
        $nodes = $crawler->filter($selector);
        if ($nodes->count() === 0) {
            continue;
        }

        foreach ($nodes as $node) {
            $title = trim((string)$node->textContent);
            if ($title !== '' && mb_strlen($title) >= 5) {
                $titles[] = $title;
            }
            if (count($titles) >= $limit) {
                break 2;
            }
        }
    }

    if (!$titles) {
        foreach ($crawler->filter('title') as $titleNode) {
            $title = trim((string)$titleNode->textContent);
            if ($title !== '' && mb_strlen($title) >= 5) {
                $titles[] = $title;
            }
            if (count($titles) >= $limit) {
                break;
            }
        }
    }

    return mergeAndDeduplicateTitles($titles);
}

function extractTitlesFromNormalPage($url, $limit = 50) {
    $htmlString = fetchUrlBody($url);
    if (!is_string($htmlString) || trim($htmlString) === '') {
        return [];
    }

    return extractTitlesFromNormalPageWithSymfonyCrawler($htmlString, $limit);
}

<?php

function getActiveNicheSlug() {
    static $cached = null;
    if ($cached !== null) return $cached;

    $q = trim((string)($_GET['niche'] ?? ''));
    if ($q !== '') {
        $slug = preg_replace('/[^a-z0-9]+/i', '-', $q);
        $slug = trim(strtolower((string)$slug), '-');
        if ($slug !== '') {
            $cached = $slug;
            return $cached;
        }
    }

    $cfg = trim((string)getSetting('active_niche', 'general'));
    $cached = $cfg !== '' ? $cfg : 'general';
    return $cached;
}

function setActiveNicheSlug($slug) {
    setSetting('active_niche', trim((string)$slug));
}

function listNiches() {
    if (!class_exists('App\\NicheManager')) return [];
    return \App\NicheManager::listNiches();
}

function seedDefaultNiches() {
    if (!class_exists('App\\NicheManager')) return;
    \App\NicheManager::seedDefaults();
}

function getActiveNicheId() {
    static $cachedId = null;
    if ($cachedId !== null) return $cachedId;

    $slug = getActiveNicheSlug();
    if (!class_exists('App\\NicheManager')) {
        $cachedId = 1;
        return $cachedId;
    }

    $niche = \\App\NicheManager::getNicheBySlug($slug);
    if ($niche) {
        $cachedId = (int)$niche['id'];
        return $cachedId;
    }

    $stmt = db_connect()->prepare("SELECT id FROM niches ORDER BY id LIMIT 1");
    $stmt->execute();
    $firstId = $stmt->fetchColumn();
    $cachedId = $firstId ? (int)$firstId : 1;
    return $cachedId;
}

function getActiveNicheInfo($slug = '') {
    static $infoCache = [];
    if ($slug === '') {
        $slug = getActiveNicheSlug();
    }
    if (isset($infoCache[$slug])) {
        return $infoCache[$slug];
    }

    if (!class_exists('App\\NicheManager')) {
        $infoCache[$slug] = [
            'slug' => $slug,
            'name' => 'General',
            'description' => 'General articles and news.',
        ];
        return $infoCache[$slug];
    }

    $niche = \\App\NicheManager::getNicheBySlug($slug);
    if (!$niche) {
        $infoCache[$slug] = [
            'slug' => $slug,
            'name' => 'General',
            'description' => 'General articles and news.',
        ];
        return $infoCache[$slug];
    }

    $infoCache[$slug] = [
        'slug' => (string)($niche['slug'] ?? ''),
        'name' => (string)($niche['name'] ?? 'General'),
        'description' => (string)($niche['description'] ?? ''),
    ];

    return $infoCache[$slug];
}

function getNicheById($id) {
    if (!class_exists('App\\NicheManager')) return null;
    return \\App\NicheManager::getNicheById((int)$id);
}

function getNicheSetting($key, $default = null) {
    $active = getActiveNicheSlug();
    $fullKey = 'niche.' . $active . '.' . $key;
    $val = getSetting($fullKey, $default);
    return $val !== null ? $val : $default;
}

function getNicheArticleMeta($slug = '') {
    $info = getActiveNicheInfo($slug);
    $slugLower = mb_strtolower((string)$info['slug'], 'UTF-8');
    $name = $info['name'] !== '' ? $info['name'] : 'General';
    $category = $name;
    $label = $name;
    $introContext = 'audience expectations, topical relevance, and niche-specific value';

    if ($slugLower === 'ev' || str_contains($name, 'Electric')) {
        $label = 'Electric Vehicles';
        $introContext = 'charging behavior, efficiency trends, and EV ownership confidence';
    } elseif ($slugLower === 'motorcycles' || str_contains($name, 'Motorcycle')) {
        $label = 'Motorcycle Reviews';
        $introContext = 'riding dynamics, ergonomics, and road confidence';
    } elseif (str_contains($slugLower, 'cuisine') || str_contains($name, 'Food') || str_contains($name, 'Cooking')) {
        $label = 'Food & Recipe Insights';
        $category = 'Cuisine';
        $introContext = 'recipe quality, flavor balance, and practical cooking tips';
    } elseif (str_contains($slugLower, 'health') || str_contains($name, 'Health')) {
        $label = 'Health & Wellness';
        $category = 'Health';
        $introContext = 'wellness benefits, practical routines, and evidence-based guidance';
    } elseif (str_contains($slugLower, 'business') || str_contains($name, 'Business')) {
        $label = 'Business Intelligence';
        $category = 'Business';
        $introContext = 'market trends, opportunity analysis, and strategic recommendations';
    }

    $customCategory = trim((string)getSetting('niche.' . $slugLower . '.category', ''));
    if ($customCategory !== '') {
        $category = $customCategory;
    }

    $customLabel = trim((string)getSetting('niche.' . $slugLower . '.label', ''));
    if ($customLabel !== '') {
        $label = $customLabel;
    }

    $customIntro = trim((string)getSetting('niche.' . $slugLower . '.intro_context', ''));
    if ($customIntro !== '') {
        $introContext = $customIntro;
    }

    return [
        'slug' => $info['slug'],
        'name' => $name,
        'description' => $info['description'],
        'label' => $label,
        'category' => $category,
        'intro_context' => $introContext,
    ];
}

function getNicheContentType(array $nicheMeta) {
    $slug = mb_strtolower(trim((string)$nicheMeta['slug']), 'UTF-8');
    $label = mb_strtolower(trim((string)$nicheMeta['label']), 'UTF-8');

    if ($slug === 'cuisine' || str_contains($label, 'food') || str_contains($label, 'recipe')) {
        return 'food';
    }
    if (str_contains($slug, 'money') || str_contains($slug, 'finance') || str_contains($label, 'finance') || str_contains($label, 'business')) {
        return 'finance';
    }
    if ($slug === 'ev' || $slug === 'motorcycles' || str_contains($label, 'vehicle') || str_contains($label, 'auto') || str_contains($label, 'car') || str_contains($label, 'motorcycle')) {
        return 'auto';
    }

    return 'general';
}

function getNicheSections($nicheType) {
    switch ($nicheType) {
        case 'food':
            return [
                'Recipe Overview and Purpose' => [
                    'dish intent, target eater, and recipe style',
                    'what makes this recipe different from common alternatives',
                    'how the finished dish should feel in terms of texture and flavor balance'
                ],
                'Ingredients and Preparation Notes' => [
                    'the quality of core ingredients and why they matter',
                    'critical technique points that determine success',
                    'time, tools, and skill level required for the recipe'
                ],
                'Flavor Profile and Serving Suggestions' => [
                    'the main taste identities and how they combine',
                    'pairing ideas that complement the dish rather than overpower it',
                    'presentation and garnish advice for better enjoyment'
                ],
                'Nutrition, Value, and Practical Use' => [
                    'how the recipe fits into daily meal planning or special occasions',
                    'value for money considering pantry ingredients and preparation effort',
                    'what readers should expect in terms of leftovers, reheating, or storage'
                ],
                'Final Verdict and Reader Recommendation' => [
                    'who benefits most from making this dish',
                    'what to watch for when choosing variations or substitutions',
                    'why this recipe earns a place in the reader’s regular cooking rotation'
                ],
            ];
        case 'finance':
            return [
                'What This Topic Delivers' => [
                    'the practical business or financial outcome it targets',
                    'how it differs from common alternatives or simpler approaches',
                    'the type of reader who benefits most from it'
                ],
                'Cost, Risk, and Reward' => [
                    'the main risks to watch for before committing',
                    'the reward profile in terms of savings, returns, or efficiency',
                    'how to compare it with other viable options'
                ],
                'Implementation and Usage Guidance' => [
                    'the steps needed to put this concept into practice',
                    'common mistakes and how to avoid them',
                    'where this approach fits into broader financial planning'
                ],
                'Audience Scenarios' => [
                    'which reader segments should prioritize it',
                    'how the recommendation changes depending on goals',
                    'the key questions to ask before choosing it'
                ],
                'Final Verdict and Strategic Recommendation' => [
                    'whether this topic is worth action now',
                    'the main conditions under which it makes the most sense',
                    'what a smart reader should do next'
                ],
            ];
        default:
            return [
                'Executive Summary and Market Position' => [
                    'segment fit and target audience clarity',
                    'how the model differentiates against direct rivals',
                    'the real value story behind headline marketing claims'
                ],
                'Exterior Design, Proportion, and Visual Character' => [
                    'surface treatment, stance, and brand identity execution',
                    'aerodynamic decisions that influence both style and efficiency',
                    'why design coherence affects both style and efficiency'
                ],
                'Cabin Quality, Space, and Human-Centered Ergonomics' => [
                    'seat comfort, posture support, and long-distance usability',
                    'dashboard hierarchy, physical controls, and interaction clarity',
                    'perceived quality through materials, fit, and acoustic control'
                ],
                'Powertrain Intelligence, Performance Delivery, and Efficiency' => [
                    'response quality under partial and full throttle situations',
                    'efficiency behavior in urban, mixed, and highway duty cycles',
                    'engineering trade-offs between excitement and sustainability'
                ],
                'Ride Comfort, Handling Balance, and Braking Confidence' => [
                    'suspension tuning over varied road surfaces',
                    'steering communication and directional stability at speed',
                    'predictable braking behavior in repeated real-world use'
                ],
                'Technology Stack, Infotainment, and Connectivity Experience' => [
                    'interface speed, readability, and cognitive simplicity',
                    'smartphone integration and navigation reliability in practice',
                    'software maturity, update path, and feature longevity'
                ],
                'Safety Systems, Driver Assistance, and Durability Outlook' => [
                    'calibration quality of active safety interventions',
                    'passive safety confidence and structural reassurance',
                    'maintenance predictability and long-term reliability perception'
                ],
                'Ownership Economics, Trim Strategy, and Buyer Recommendations' => [
                    'cost of ownership across fuel or charging, service, and insurance',
                    'which configuration levels provide the strongest value density',
                    'how to shortlist based on real priorities rather than hype'
                ],
            ];
    }
}

function getNicheSources($nicheSlug = '', $type = '') {
    if ($nicheSlug === '') {
        $nicheSlug = getActiveNicheSlug();
    }
    if (!class_exists('App\\NicheManager')) {
        return [];
    }

    $niche = \\App\NicheManager::getNicheBySlug($nicheSlug);
    if (!$niche) {
        return [];
    }

    $sources = \\App\NicheManager::getSourcesForNiche((int)$niche['id'], $type);
    return array_column($sources, 'url');
}

function getNicheRssSources($nicheSlug = '') {
    return getNicheSources($nicheSlug, 'rss');
}

function getNicheWebSources($nicheSlug = '') {
    return getNicheSources($nicheSlug, 'web');
}

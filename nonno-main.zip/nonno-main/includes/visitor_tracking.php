<?php

function getVisitorFingerprint() {
    $ip = getVisitorIpAddress();
    if ($ip === '') {
        $ip = 'unknown-ip';
    }
    return hash('sha256', $ip);
}

function getVisitorIpAddress() {
    $forwardedFor = trim((string)($_SERVER['HTTP_X_FORWARDED_FOR'] ?? ''));
    if ($forwardedFor !== '') {
        $parts = array_map('trim', explode(',', $forwardedFor));
        foreach ($parts as $candidate) {
            if ($candidate !== '' && filter_var($candidate, FILTER_VALIDATE_IP)) {
                return $candidate;
            }
        }
    }

    $remoteAddress = trim((string)($_SERVER['REMOTE_ADDR'] ?? ''));
    if ($remoteAddress !== '' && filter_var($remoteAddress, FILTER_VALIDATE_IP)) {
        return $remoteAddress;
    }

    return $remoteAddress;
}

function ipMatchesRule($ipAddress, $rule) {
    $ipAddress = trim((string)$ipAddress);
    $rule = trim((string)$rule);
    if ($ipAddress === '' || $rule === '') {
        return false;
    }

    if (strpos($rule, '/') !== false) {
        [$subnet, $maskBitsRaw] = array_pad(explode('/', $rule, 2), 2, '');
        $subnet = trim($subnet);
        $maskBits = (int)$maskBitsRaw;

        if (filter_var($subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && filter_var($ipAddress, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            if ($maskBits < 0 || $maskBits > 32) {
                return false;
            }
            $subnetLong = ip2long($subnet);
            $ipLong = ip2long($ipAddress);
            if ($subnetLong === false || $ipLong === false) {
                return false;
            }
            $mask = $maskBits === 0 ? 0 : (-1 << (32 - $maskBits));
            return (($ipLong & $mask) === ($subnetLong & $mask));
        }

        return false;
    }

    return $ipAddress === $rule;
}

function normalizeExcludedIpRules($rawValue) {
    $rawValue = trim((string)$rawValue);
    if ($rawValue === '') {
        return '';
    }

    $tokens = preg_split('/[\s,]+/', $rawValue, -1, PREG_SPLIT_NO_EMPTY);
    $rules = [];
    foreach ($tokens as $token) {
        $rule = trim((string)$token);
        if ($rule === '') {
            continue;
        }

        if (strpos($rule, '/') !== false) {
            [$subnet, $maskBitsRaw] = array_pad(explode('/', $rule, 2), 2, '');
            $subnet = trim($subnet);
            $maskBits = (int)$maskBitsRaw;
            if (filter_var($subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && $maskBits >= 0 && $maskBits <= 32) {
                $rules[] = $subnet . '/' . $maskBits;
            }
            continue;
        }

        if (filter_var($rule, FILTER_VALIDATE_IP)) {
            $rules[] = $rule;
        }
    }

    $rules = array_values(array_unique($rules));
    return implode("\n", $rules);
}

function shouldIgnoreVisitForIp($ipAddress) {
    $ipAddress = trim((string)$ipAddress);
    if ($ipAddress === '') {
        return false;
    }

    $excludedRaw = normalizeExcludedIpRules((string)getSetting('visit_excluded_ips', ''));
    if ($excludedRaw === '') {
        return false;
    }

    $rules = preg_split('/[\s,]+/', $excludedRaw, -1, PREG_SPLIT_NO_EMPTY);
    foreach ($rules as $rule) {
        if (ipMatchesRule($ipAddress, $rule)) {
            return true;
        }
    }

    return false;
}

function recordPageVisit($pageKey, $pageLabel) {
    $pageKey = trim((string)$pageKey);
    $pageLabel = trim((string)$pageLabel);
    if ($pageKey === '' || $pageLabel === '') {
        return;
    }

    $pdo = db_connect();
    $ipAddress = getVisitorIpAddress();
    if (shouldIgnoreVisitForIp($ipAddress)) {
        return;
    }

    $visitorHash = getVisitorFingerprint();
    $now = time();

    $stmt = $pdo->prepare("INSERT INTO page_visits (page_key, page_label, visitor_hash, views, created_at, updated_at)
        VALUES (:page_key, :page_label, :visitor_hash, 1, :created_at, :updated_at)
        ON CONFLICT(page_key, visitor_hash) DO UPDATE SET
            views = views + CASE
                WHEN strftime('%Y-%m-%d', page_visits.updated_at, 'unixepoch') = strftime('%Y-%m-%d', excluded.updated_at, 'unixepoch') THEN 0
                ELSE 1
            END,
            page_label = excluded.page_label,
            updated_at = excluded.updated_at");

    $stmt->execute([
        'page_key' => $pageKey,
        'page_label' => $pageLabel,
        'visitor_hash' => $visitorHash,
        'created_at' => $now,
        'updated_at' => $now,
    ]);
}

function getPageVisitStats($limit = 8, $search = '') {
    $limit = max(1, min(30, (int)$limit));
    $pdo = db_connect();
    if ($search !== '') {
        $stmt = $pdo->prepare("SELECT
            page_key,
            MIN(page_label) AS page_label,
            SUM(views) AS total_views,
            COUNT(*) AS unique_visitors,
            SUM(CASE WHEN updated_at >= :last_24h THEN 1 ELSE 0 END) AS visitors_24h,
            MAX(updated_at) AS last_visit_at
        FROM page_visits
        WHERE page_label LIKE :search OR page_key LIKE :search
        GROUP BY page_key
        ORDER BY total_views DESC
        LIMIT :limit");
        $stmt->bindValue(':search', '%' . $search . '%', PDO::PARAM_STR);
    } else {
        $stmt = $pdo->prepare("SELECT
            page_key,
            MIN(page_label) AS page_label,
            SUM(views) AS total_views,
            COUNT(*) AS unique_visitors,
            SUM(CASE WHEN updated_at >= :last_24h THEN 1 ELSE 0 END) AS visitors_24h,
            MAX(updated_at) AS last_visit_at
        FROM page_visits
        GROUP BY page_key
        ORDER BY total_views DESC
        LIMIT :limit");
    }
    $stmt->bindValue(':last_24h', time() - 86400, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

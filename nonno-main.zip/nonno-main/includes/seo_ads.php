<?php

function parseSeoAutoLinkRules($rawRules) {
    $rules = [];
    $lines = preg_split('/\r\n|\r|\n/', (string)$rawRules);
    foreach ($lines as $line) {
        $line = trim((string)$line);
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }

        $parts = array_map('trim', explode('|', $line));
        if (count($parts) < 1) {
            continue;
        }

        $keyword = trim((string)($parts[0] ?? ''));
        $destination = trim((string)($parts[1] ?? 'internal'));
        if ($keyword === '' || $destination === '') {
            continue;
        }

        $rules[] = [
            'keyword' => $keyword,
            'destination' => $destination,
            'new_tab' => isset($parts[2]) ? in_array(strtolower($parts[2]), ['1', 'yes', 'true', 'newtab', 'blank'], true) : false,
            'nofollow' => isset($parts[3]) ? in_array(strtolower($parts[3]), ['1', 'yes', 'true', 'nofollow'], true) : false,
        ];
    }

    return $rules;
}

function resolveSeoAutoLinkDestination(array $rule, $currentArticleId = 0) {
    $destination = trim((string)($rule['destination'] ?? ''));
    if ($destination === '') {
        return null;
    }

    if (preg_match('/^https?:\/\//i', $destination)) {
        return [
            'url' => $destination,
            'external' => true,
        ];
    }

    if (str_starts_with($destination, 'slug:')) {
        $slug = slugify(substr($destination, 5));
        if ($slug === '') {
            return null;
        }

        return [
            'url' => 'index.php?slug=' . rawurlencode($slug),
            'external' => false,
        ];
    }

    if (strtolower($destination) === 'internal') {
        $pdo = db_connect();
        $stmt = $pdo->prepare("SELECT slug FROM articles WHERE id != ? AND title LIKE ? ORDER BY id DESC LIMIT 1");
        $stmt->execute([(int)$currentArticleId, '%' . $rule['keyword'] . '%']);
        $slug = (string)$stmt->fetchColumn();
        if ($slug === '') {
            return null;
        }

        return [
            'url' => 'index.php?slug=' . rawurlencode($slug),
            'external' => false,
        ];
    }

    if (str_starts_with($destination, '/')) {
        return [
            'url' => $destination,
            'external' => false,
        ];
    }

    return null;
}

function buildAutomaticInternalLinkRules($currentArticleId = 0, $limit = 3) {
    $limit = max(1, min(10, (int)$limit));
    $pdo = db_connect();
    $stmt = $pdo->prepare("SELECT title, slug FROM articles WHERE id != ? ORDER BY id DESC LIMIT 30");
    $stmt->execute([(int)$currentArticleId]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $rules = [];
    foreach ($rows as $row) {
        $title = trim((string)($row['title'] ?? ''));
        $slug = trim((string)($row['slug'] ?? ''));
        if ($title === '' || $slug === '') {
            continue;
        }

        $keyword = $title;
        if (mb_strlen($keyword) > 80) {
            $keyword = mb_substr($keyword, 0, 80);
        }

        $rules[] = [
            'keyword' => $keyword,
            'destination' => 'slug:' . $slug,
            'new_tab' => false,
            'nofollow' => false,
        ];

        if (count($rules) >= $limit) {
            break;
        }
    }

    return $rules;
}

function injectSeoAutoLinks($html, $currentArticleId = 0) {
    $content = trim((string)$html);
    if ($content === '') {
        return $html;
    }

    $rules = parseSeoAutoLinkRules(getSetting('seo_auto_link_rules', ''));

    $autoInternalEnabled = getSettingInt('seo_auto_link_auto_internal', 1, 0, 1) === 1;
    $autoInternalLimit = getSettingInt('seo_auto_link_max_per_article', 3, 1, 10);
    if ($autoInternalEnabled) {
        $rules = array_merge($rules, buildAutomaticInternalLinkRules($currentArticleId, $autoInternalLimit));
    }

    if (!$rules) {
        return $html;
    }

    $resolved = [];
    foreach ($rules as $rule) {
        $target = resolveSeoAutoLinkDestination($rule, $currentArticleId);
        if (!$target || trim((string)($target['url'] ?? '')) === '') {
            continue;
        }
        $rule['url'] = $target['url'];
        $rule['external'] = (bool)($target['external'] ?? false);
        $keywordHash = mb_strtolower((string)($rule['keyword'] ?? ''));
        if ($keywordHash === '' || isset($resolved[$keywordHash])) {
            continue;
        }
        $resolved[$keywordHash] = $rule;
    }

    if (!$resolved) {
        return $html;
    }

    $wrappedHtml = '<div id="article-content-root">' . $content . '</div>';
    $previousUseErrors = libxml_use_internal_errors(true);
    $dom = new DOMDocument('1.0', 'UTF-8');
    $loaded = $dom->loadHTML('<?xml encoding="utf-8" ?>' . $wrappedHtml, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    libxml_clear_errors();
    libxml_use_internal_errors($previousUseErrors);

    if (!$loaded) {
        return $html;
    }

    $xpath = new DOMXPath($dom);
    $textNodes = $xpath->query('//div[@id="article-content-root"]//text()[normalize-space(.)!="" and not(ancestor::a) and not(ancestor::script) and not(ancestor::style) and not(ancestor::h1) and not(ancestor::h2) and not(ancestor::h3)]');
    if (!$textNodes || $textNodes->length === 0) {
        return $html;
    }

    $resolved = array_values($resolved);
    $usedKeywords = [];
    foreach ($textNodes as $textNode) {
        $text = (string)$textNode->nodeValue;
        if ($text === '') {
            continue;
        }

        foreach ($resolved as $rule) {
            $keyword = (string)$rule['keyword'];
            $keyHash = mb_strtolower($keyword);
            if ($keyword === '' || isset($usedKeywords[$keyHash])) {
                continue;
            }

            $pattern = '/(?<![\p{L}\p{N}])(' . preg_quote($keyword, '/') . ')(?![\p{L}\p{N}])/ui';
            if (!preg_match($pattern, $text)) {
                continue;
            }

            $replacement = '<a href="' . e($rule['url']) . '" class="seo-auto-link"';
            $openInNewTab = !empty($rule['new_tab']) || !empty($rule['external']);
            if ($openInNewTab) {
                $replacement .= ' target="_blank"';
            }

            $relParts = [];
            if ($openInNewTab) {
                $relParts[] = 'noopener';
            }
            if (!empty($rule['nofollow'])) {
                $relParts[] = 'nofollow';
            }
            if ($relParts) {
                $replacement .= ' rel="' . implode(' ', $relParts) . '"';
            }
            $replacement .= '>$1</a>';

            $updated = preg_replace($pattern, $replacement, $text, 1);
            if ($updated === null || $updated === $text) {
                continue;
            }

            $fragment = $dom->createDocumentFragment();
            if (!$fragment->appendXML($updated)) {
                continue;
            }

            $textNode->parentNode->replaceChild($fragment, $textNode);
            $usedKeywords[$keyHash] = true;
            break;
        }
    }

    $root = $dom->getElementById('article-content-root');
    if (!$root) {
        return $html;
    }

    $result = "";
    foreach ($root->childNodes as $child) {
        $result .= $dom->saveHTML($child);
    }

    return $result !== "" ? $result : $html;
}

function buildInlineAdUnitHtml(array $adSettings, $position = 1) {
    $safePosition = max(1, (int)$position);
    $label = e($adSettings['label'] ?? 'Sponsored');
    $adCode = (string)($adSettings['html_code'] ?? '');
    if ($adCode === '') {
        $adCode = '<div class="ad-unit-inner">Place your ad code here</div>';
    }

    return '<aside class="inline-ad-unit" data-ad-slot="' . $safePosition . '">' .
        '<div class="inline-ad-label">' . $label . '</div>' .
        $adCode .
        '</aside>';
}

function injectAdsIntoArticleContent($html, $articleTitle = '', $articleCategory = '') {
    $content = trim((string)$html);
    if ($content === '') {
        return $html;
    }

    if (stripos($content, 'inline-ad-unit') !== false) {
        return $html;
    }

    $adSettings = getAdSettings();
    if (!$adSettings['enabled']) {
        return $html;
    }

    $maxUnits = (int)$adSettings['max_units'];
    $interval = (int)$adSettings['paragraph_interval'];
    $minWords = (int)$adSettings['min_words_before_first'];
    $minArticleWords = (int)$adSettings['min_article_words'];

    $articleWordCount = countVisibleWords(strip_tags($content));
    if ($articleWordCount < $minArticleWords) {
        return $html;
    }

    $titleKeywords = parseAdBlockedTitleKeywords($adSettings['blocked_title_keywords'] ?? '');
    if ($titleKeywords) {
        $title = mb_strtolower(trim((string)$articleTitle));
        foreach ($titleKeywords as $keyword) {
            if ($title !== '' && mb_stripos($title, $keyword) !== false) {
                return $html;
            }
        }
    }

    $blockedCategories = parseAdListTokens($adSettings['blocked_categories'] ?? '');
    if ($blockedCategories) {
        $category = mb_strtolower(trim((string)$articleCategory));
        if ($category !== '' && in_array($category, $blockedCategories, true)) {
            return $html;
        }
    }

    $wrappedHtml = '<div id="article-content-root">' . $content . '</div>';
    $previousUseErrors = libxml_use_internal_errors(true);
    $dom = new DOMDocument('1.0', 'UTF-8');
    $loaded = $dom->loadHTML('<?xml encoding="utf-8" ?>' . $wrappedHtml, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    libxml_clear_errors();
    libxml_use_internal_errors($previousUseErrors);

    if (!$loaded) {
        return $html;
    }

    $root = $dom->getElementById('article-content-root');
    if (!$root) {
        return $html;
    }

    $candidates = [];
    foreach ($root->childNodes as $child) {
        if (!($child instanceof DOMElement)) {
            continue;
        }

        $tag = strtolower($child->tagName);
        if (!in_array($tag, ['p', 'ul', 'ol', 'blockquote', 'h2', 'h3'], true)) {
            continue;
        }

        $text = trim((string)$child->textContent);
        if ($text === '') {
            continue;
        }

        $candidates[] = [
            'node' => $child,
            'tag' => $tag,
            'words' => countVisibleWords($text),
            'text_len' => mb_strlen($text),
        ];
    }

    if (count($candidates) < 3) {
        return $html;
    }

    $indexes = [];
    $runningWords = 0;
    $lastIndex = -999;

    foreach ($candidates as $idx => $candidate) {
        $runningWords += (int)$candidate['words'];
        if ($idx < 1 || $idx >= count($candidates) - 1) {
            continue;
        }

        $shouldInject = false;
        if ($adSettings['mode'] === 'interval') {
            $shouldInject = $idx > 0 && $idx % $interval === 0;
        } else {
            $substantial = (int)$candidate['text_len'] >= 180 || (int)$candidate['words'] >= 28;
            $firstThreshold = $runningWords >= $minWords;
            $spacingOkay = ($idx - $lastIndex) >= max(2, $interval - 1);
            $shouldInject = $substantial && $firstThreshold && $spacingOkay;
        }

        if ($shouldInject) {
            $indexes[] = $idx;
            $lastIndex = $idx;
            if (count($indexes) >= $maxUnits) {
                break;
            }
        }
    }

    if (!$indexes) {
        return $html;
    }

    $adCount = 0;
    foreach ($indexes as $idx) {
        $targetNode = $candidates[$idx]['node'];
        $adCount++;

        $fragment = $dom->createDocumentFragment();
        $fragment->appendXML(buildInlineAdUnitHtml($adSettings, $adCount));

        if ($targetNode->nextSibling) {
            $targetNode->parentNode->insertBefore($fragment, $targetNode->nextSibling);
        } else {
            $targetNode->parentNode->appendChild($fragment);
        }
    }

    $result = '';
    foreach ($root->childNodes as $child) {
        $result .= $dom->saveHTML($child);
    }

    return $result !== '' ? $result : $html;
}

function getAutoTitleDefaultSettings() {
    return [
        'auto_title_mode' => 'template',
        'auto_title_min_year_offset' => '0',
        'auto_title_max_year_offset' => '1',
        'auto_title_brands' => "Toyota
BMW
Mercedes
Audi
Porsche
Tesla
Hyundai
Kia
Ford
Nissan
Volvo
Lexus",
        'auto_title_models' => "SUV
Sedan
Coupe
EV Crossover
Hybrid SUV
Performance Hatchback
Electric Sedan
Luxury Wagon
Premium Crossover",
        'auto_title_modifiers' => "Review
Specs
Price
Comparison
Buying Guide
Ownership Cost",
        'auto_title_audiences' => "Smart Buyers
First-Time Premium Buyers
Tech-Focused Drivers
Family Buyers",
        'auto_title_angles' => "Full Review and Buyer Guide
Long-Term Ownership Analysis
Real-World Efficiency Test
Daily Driving Impression
Smart Technology Deep Dive
Comparison and Value Breakdown
Reliability, Resale, and Total Cost Breakdown",
        'auto_title_templates' => "{year} {brand} {model} {modifier}: {angle} for {audience}
{year} {brand} {model} {modifier} — {angle} ({audience})
{year} {brand} {model}: {modifier} + {angle}",
        'auto_title_fixed_titles' => '',
    ];
}

function getAutoTitleSetting($key) {
    $defaults = getAutoTitleDefaultSettings();
    $fallback = $defaults[$key] ?? '';

    $activeNiche = trim((string)getActiveNicheSlug());
    if ($activeNiche !== '') {
        $nicheValue = getSetting('niche.' . $activeNiche . '.' . $key, null);
        if ($nicheValue !== null && trim((string)$nicheValue) !== '') {
            return (string)$nicheValue;
        }
    }

    return (string)getSetting($key, $fallback);
}

function parseSettingList($key, $fallback) {
    $raw = (string)getAutoTitleSetting($key);
    if (trim($raw) === '') {
        $raw = (string)$fallback;
    }
    $lines = preg_split('/\r\n|\r|\n/', $raw) ?: [];
    $clean = [];

    foreach ($lines as $line) {
        $value = trim((string)$line);
        if ($value !== '') {
            $clean[] = $value;
        }
    }

    return $clean;
}

function pickRandomFromList(array $items, $fallback = '') {
    if (!$items) {
        return (string)$fallback;
    }

    return (string)$items[array_rand($items)];
}

function generateAutoTitle() {
    $mode = trim(getAutoTitleSetting('auto_title_mode'));

    if ($mode === 'list') {
        $fixedTitles = parseSettingList('auto_title_fixed_titles', '');
        if ($fixedTitles) {
            return pickRandomFromList($fixedTitles);
        }
        $mode = 'template';
    }

    $minOffset = (int)getAutoTitleSetting('auto_title_min_year_offset');
    $maxOffset = (int)getAutoTitleSetting('auto_title_max_year_offset');
    $minOffset = max(-1, min(2, $minOffset));
    $maxOffset = max(-1, min(3, $maxOffset));
    if ($maxOffset < $minOffset) {
        [$minOffset, $maxOffset] = [$maxOffset, $minOffset];
    }

    $year = (int)date('Y') + rand($minOffset, $maxOffset);
    $brand = pickRandomFromList(parseSettingList('auto_title_brands', getAutoTitleSetting('auto_title_brands')), 'Toyota');
    $model = pickRandomFromList(parseSettingList('auto_title_models', getAutoTitleSetting('auto_title_models')), 'SUV');
    $modifier = pickRandomFromList(parseSettingList('auto_title_modifiers', getAutoTitleSetting('auto_title_modifiers')), 'Review');
    $audience = pickRandomFromList(parseSettingList('auto_title_audiences', getAutoTitleSetting('auto_title_audiences')), 'Smart Buyers');
    $angle = pickRandomFromList(parseSettingList('auto_title_angles', getAutoTitleSetting('auto_title_angles')), 'Full Review and Buyer Guide');

    $templates = parseSettingList('auto_title_templates', getAutoTitleSetting('auto_title_templates'));
    if (!$templates) {
        $templates = ['{year} {brand} {model} {modifier}: {angle} for {audience}'];
    }

    $template = pickRandomFromList($templates, '{year} {brand} {model} {modifier}: {angle} for {audience}');
    $replacements = [
        '{year}' => (string)$year,
        '{brand}' => $brand,
        '{model}' => $model,
        '{modifier}' => $modifier,
        '{audience}' => $audience,
        '{angle}' => $angle,
    ];

    return trim(strtr($template, $replacements));
}

function generateUniqueAutoTitle($maxAttempts = 12) {
    $attempts = max(1, (int)$maxAttempts);
    for ($i = 0; $i < $attempts; $i++) {
        $title = generateAutoTitle();
        if (!articleExists($title)) {
            return $title;
        }
    }

    return null;
}

function publishAutoArticleBySchedule($force = false) {
    $enabled = getSettingInt('auto_ai_enabled', 1, 0, 1);
    if (!$force && $enabled !== 1) {
        return ['published' => 0, 'reason' => 'disabled'];
    }

    $intervalSeconds = getAutoPublishIntervalSeconds();
    $lastRun = strtotime((string)getSetting('auto_publish_last_run_at', '1970-01-01 00:00:00')) ?: 0;
    $now = time();

    if (!$force && ($now - $lastRun) < $intervalSeconds) {
        return ['published' => 0, 'reason' => 'not_due'];
    }

    $title = generateUniqueAutoTitle();
    if ($title === null) {
        return ['published' => 0, 'reason' => 'title_generation_failed'];
    }

    $data = generateArticle($title);
    if (!saveArticle($title, $data)) {
        return ['published' => 0, 'reason' => 'duplicate_title_or_content'];
    }
    setSetting('auto_publish_last_run_at', date('Y-m-d H:i:s', $now));

    return ['published' => 1, 'reason' => 'ok', 'title' => $title];
}

function getRandomIntro($title, array $nicheMeta = []) {
    $slug = mb_strtolower((string)($nicheMeta['slug'] ?? ''), 'UTF-8');
    $nicheLabel = trim((string)($nicheMeta['label'] ?? ''));
    $introContext = trim((string)($nicheMeta['intro_context'] ?? ''));
    $isCuisine = str_contains($slug, 'cuisine') || str_contains(mb_strtolower($nicheLabel, 'UTF-8'), 'food');
    $isHealth = str_contains($slug, 'health');
    $isBusiness = str_contains($slug, 'business') || str_contains($nicheLabel, 'Business');
    $isEV = $slug === 'ev' || str_contains($nicheLabel, 'Electric');

    $intros = [];
    if ($isCuisine) {
        $intros = [
            "The $title is designed to help home cooks and food lovers make smarter, tastier choices in the kitchen.",
            "For the $title, flavor balance, preparation clarity, and ingredient quality are the strongest selling points.",
            "This $title combines approachable cooking guidance with practical recipe insights that matter to everyday chefs.",
        ];
    } elseif ($isHealth) {
        $intros = [
            "The $title is framed around real wellness benefits and practical steps ordinary readers can use.",
            "With the $title, the focus is on evidence-based advice, easy-to-follow habits, and sustainable lifestyle improvements.",
            "This $title is tailored for people who want clear health guidance rather than vague motivational messaging.",
        ];
    } elseif ($isBusiness) {
        $intros = [
            "The $title is structured to separate signal from noise in a fast-moving business context.",
            "This article looks beyond headlines to uncover the real strategy, risk, and financial implications behind the story.",
            "For readers focused on opportunity and outcome, the $title outlines the practical decisions that matter most.",
        ];
    } elseif ($isEV) {
        $intros = [
            "The $title is evaluated through the lens of charging readiness, range confidence, and real-world efficiency.",
            "This electric model is judged not just on specs, but on how well it supports daily routines and long-term ownership.",
            "The $title is built for drivers who care about consistent range performance, software stability, and charging convenience.",
        ];
    } else {
        $intros = [
            "The $title arrives at a time when buyers expect more than raw performance—they expect intelligence, consistency, and real ownership value.",
            "The $title reflects a modern automotive philosophy where design, software, efficiency, and durability must all work together.",
            "With the $title, the brand is clearly targeting drivers who care about emotional appeal and practical decision-making in equal measure.",
            "The $title enters a competitive segment, and its real strength is how it balances premium character with day-to-day usability.",
        ];
    }

    if ($introContext !== '') {
        $intros[] = "This article centers on {$introContext} so that the $title review is more useful for informed buyers.";
    }

    return $intros[array_rand($intros)];
}

function getNicheWritingAngle(array $nicheMeta) {
    $slug = mb_strtolower((string)$nicheMeta['slug'], 'UTF-8');
    if ($slug === 'ev' || str_contains((string)$nicheMeta['label'], 'Electric')) {
        return 'charging behavior, energy efficiency, and software maturity';
    }
    if ($slug === 'motorcycles') {
        return 'riding dynamics, ergonomic fit, and control confidence';
    }
    if (str_contains($slug, 'cuisine') || str_contains((string)$nicheMeta['label'], 'Food')) {
        return 'ingredient quality, recipe usefulness, and flavor consistency';
    }
    if (str_contains($slug, 'business') || str_contains((string)$nicheMeta['label'], 'Business')) {
        return 'market relevance, financial clarity, and strategic decision-making';
    }
    return 'real ownership value, practical usability, and competitive positioning';
}

function buildNicheSeoKeywords($title, array $nicheMeta) {
    $keywords = [
        $title,
        $title . ' review',
        $title . ' best features',
        $title . ' buying advice',
        $title . ' reliability',
        $title . ' pros and cons',
        $title . ' vs competitors',
    ];

    $nicheLabel = trim((string)$nicheMeta['label']);
    if ($nicheLabel !== '' && mb_strtolower($nicheLabel, 'UTF-8') !== 'general') {
        $keywords[] = $nicheLabel . ' review';
        $keywords[] = $nicheLabel . ' buying guide';
    }

    $topicContext = trim((string)$nicheMeta['intro_context']);
    if ($topicContext !== '') {
        $keywords[] = $title . ' ' . $topicContext;
    }

    return array_values(array_unique(array_filter(array_map('trim', $keywords))));
}

function getArticleExpansionLibrary($title, array $nicheMeta) {
    $nicheLabel = trim((string)$nicheMeta['label']);

    return [
        "<p>Beyond specifications, the {$title} should be evaluated through lifecycle quality: software stability, service access, parts availability, and dealer competence. These ownership signals are especially important for {$nicheLabel} buyers who want lasting value rather than a good first impression.</p>",
        "<p>A final strategic angle concerns resale narrative. Products that preserve a strong identity, avoid unnecessary complexity, and maintain predictable reliability tend to keep value better. The {$title} appears aligned with that principle by emphasizing balance instead of gimmicks.</p>",
        "<p>From a product planning perspective, the {$title} signals where the brand may be heading next: stronger system integration, higher efficiency discipline, and a clearer user-first direction. Those are the kinds of improvements that matter for thoughtful {$nicheLabel} readers.</p>",
    ];
}

function pickRandomFrom(array $items) {
    return $items[array_rand($items)];
}

function buildAnalyticalParagraph($title, $sectionTitle, $focus, $nicheType, $perspective) {
    $energyContext = $nicheType === 'auto'
        ? ($sectionTitle === 'Powertrain Intelligence, Performance Delivery, and Efficiency'
            ? 'its electric architecture, battery management logic, and charging ecosystem'
            : 'its engine calibration, transmission strategy, and thermal durability')
        : 'its practical characteristics, execution quality, and real-world suitability';

    if ($nicheType === 'food') {
        $openingBank = [
            "For {$sectionTitle}, the {$title} should be judged by {$focus} in a kitchen-friendly way.",
            "When considering {$sectionTitle}, the most useful point is {$focus} for a satisfying final dish.",
            "A strong {$title} recipe stands out when {$focus} is handled with clarity and practical technique."
        ];
        $analysisBank = [
            "The key to a good result is consistency in flavor, texture, and timing rather than chasing complex tricks.",
            "A home cook benefits from predictable steps, understandable ingredients, and a final result that tastes balanced.",
            "This recipe succeeds when the elements work together without overwhelming the main character of the dish."
        ];
        $perspectiveBank = [
            "For everyday cooking, that means fewer surprises and more confidence in the outcome.",
            "When you prepare this for guests, the most memorable part should be the harmony of flavors and the ease of execution.",
            "A practical recipe is one you are happy to make again, not one that only looks impressive on the first try."
        ];
        $closingBank = [
            "That kind of coherence is what makes {$title} feel like a dependable kitchen choice rather than a one-off experiment.",
            "In the end, a successful dish is judged by how well it delivers enjoyment, repeatability, and sensible preparation.",
            "Ultimately, this is a recipe you want to return to because it balances taste, effort, and reliability."
        ];
    } elseif ($nicheType === 'finance') {
        $openingBank = [
            "In the context of {$sectionTitle}, the {$title} should be measured by {$focus}.",
            "This topic becomes meaningful when {$focus} is evaluated against real financial outcomes.",
            "A smart decision is built around {$focus}, and that matters more than flashy short-term claims."
        ];
        $analysisBank = [
            "The stronger signal here is long-term clarity rather than a single headline benefit.",
            "Consistent results come from predictable assumptions and a realistic view of risk, not from overly aggressive projections.",
            "What separates good advice from average advice is the practical alignment with your goals, time frame, and tolerance for complexity."
        ];
        $perspectiveBank = [
            "For a business owner or investor, the right choice usually means a lower chance of regret later on.",
            "When resources are constrained, the best outcomes come from decisions that balance growth potential with discipline.",
            "A conservative approach can still be attractive if it preserves flexibility and reduces unnecessary exposure."
        ];
        $closingBank = [
            "That kind of discipline is what helps the {$title} translate theory into reliable decision-making.",
            "In practice, the best strategy is one that remains sensible under different market conditions.",
            "Ultimately, the strongest case is built on real-world execution, not just appealing jargon."
        ];
    } else {
        $openingBank = [
            "In the context of {$sectionTitle}, the {$title} deserves attention for {$focus}.",
            "Looking at {$sectionTitle} through a practical lens, {$focus} becomes one of the most relevant points for {$title}.",
            "When analysts evaluate {$sectionTitle}, they usually start with {$focus}, and the {$title} performs in a convincing way."
        ];
        $analysisBank = [
            "The most credible part of this story is not a single headline figure, but the consistency of behavior across daily scenarios like traffic, highway cruising, and weekend travel.",
            "What separates mature products from average ones is repeatability, and here the vehicle keeps a stable character even when road quality, weather, and load conditions change.",
            "Instead of over-optimizing for lab-style results, the package appears tuned for real-world confidence where comfort, control, and predictability matter every day."
        ];
        $perspectiveBank = [
            "From an owner perspective, this means fewer compromises between comfort and capability, and a lower chance of buyer regret after the first months of excitement.",
            "For mixed-use drivers, this creates a meaningful advantage: the car feels refined in city conditions yet remains composed when pushed on open roads.",
            "From a long-term standpoint, this balance supports stronger perceived quality because the driving experience remains coherent rather than fragmented."
        ];
        $closingBank = [
            "That broader coherence is reinforced by {$energyContext}, which helps the {$title} translate engineering choices into tangible daily benefits.",
            "The result is a clearer value proposition: the {$title} is not merely impressive on paper, it is understandable and rewarding in normal ownership use.",
            "Ultimately, this is where product intelligence appears—different systems collaborate naturally instead of competing for attention."
        ];
    }

    $paragraph = pickRandomFrom($openingBank) . ' '
        . pickRandomFrom($analysisBank) . ' '
        . pickRandomFrom($perspectiveBank) . ' '
        . pickRandomFrom($closingBank);

    if ($perspective !== '') {
        $paragraph .= ' ' . $perspective;
    }

    return "<p>{$paragraph}</p>";
}

function buildSectionContent($title, $sectionTitle, array $focusPoints, $nicheType, array $nicheMeta) {
    $perspectives = [
        'This is especially important in segments where buyers compare six or seven alternatives before committing.',
        'In competitive markets, small gains in usability often influence purchase decisions more than aggressive marketing claims.',
        'For families and frequent commuters, these details can be more valuable than short-term novelty features.'
    ];

    $paragraphs = [];
    foreach ($focusPoints as $index => $focus) {
        $paragraphs[] = buildAnalyticalParagraph(
            $title,
            $sectionTitle,
            $focus,
            $nicheType,
            $perspectives[$index % count($perspectives)]
        );
    }

    return $paragraphs;
}

function buildComparisonTable($title, $bodyType, $isEV) {
    $rivalMap = [
        'SUV' => ['Toyota RAV4 Hybrid', 'Honda CR-V Hybrid'],
        'Sedan' => ['Toyota Camry', 'Honda Accord'],
        'Truck' => ['Ford Ranger', 'Toyota Hilux'],
        'Coupe' => ['BMW 4 Series', 'Audi A5'],
        'Hatchback' => ['Volkswagen Golf', 'Mazda 3'],
    ];

    $rivals = $rivalMap[$bodyType] ?? ['Segment Benchmark Model', 'Value-Focused Alternative'];
    $efficiencyMetric = $isEV ? 'Range (km est.)' : 'Fuel Economy (L/100km)';
    $efficiencyValue = $isEV ? (string)rand(460, 690) : (string)rand(6, 10);

    return "<h2>Competitor Comparison at a Glance</h2>
" .
        "<p>Buyers searching for {$title} alternatives usually compare real ownership outcomes, not only launch marketing numbers. This table highlights how {$title} stacks up against common choices in the same {$bodyType} category.</p>
" .
        "<div class='table-responsive'><table class='table table-striped table-bordered'><thead><tr><th>Model</th><th>Positioning</th><th>{$efficiencyMetric}</th><th>Best For</th></tr></thead><tbody>" .
        "<tr><td><strong>{$title}</strong></td><td>Balanced performance + daily practicality</td><td>{$efficiencyValue}</td><td>Buyers wanting long-term ownership confidence</td></tr>" .
        "<tr><td>{$rivals[0]}</td><td>Mainstream benchmark setup</td><td>Competitive</td><td>Drivers prioritizing proven familiarity</td></tr>" .
        "<tr><td>{$rivals[1]}</td><td>Value-first package</td><td>Strong on paper</td><td>Cost-sensitive buyers with simpler needs</td></tr>" .
        "</tbody></table></div>
";
}

function buildBuyingChecklistSection($title, $isEV) {
    $specificPoint = $isEV
        ? 'Verify home charging readiness, local fast-charging coverage, and expected charging curve behavior in your climate.'
        : 'Check expected fuel economy in your driving pattern and compare maintenance package coverage by dealership.';

    return "<h2>Pre-Purchase Checklist</h2>
" .
        "<p>Before finalizing {$title}, use this shortlist to reduce buyer regret and improve long-term value:</p>
" .
        "<ol>" .
        "<li>Compare trims by safety and comfort features, not badge labels alone.</li>" .
        "<li>{$specificPoint}</li>" .
        "<li>Request a real-world test route that includes city traffic, rough roads, and highway speeds.</li>" .
        "<li>Confirm warranty details, service intervals, and total ownership cost projections for 3–5 years.</li>" .
        "</ol>
";
}

function buildPeopleAlsoAskSection($title, $isEV) {
    $chargingQuestion = $isEV
        ? "<li><strong>How fast can {$title} charge in daily use?</strong> Charging speed depends on charger type and battery state, but owners should prioritize charging curve stability and local infrastructure quality over peak brochure numbers.</li>"
        : "<li><strong>Is {$title} fuel-efficient enough for daily commuting?</strong> Real-world efficiency is strongest when traffic, maintenance, and driving style are considered together instead of relying on ideal test cycles.</li>";

    return "<h2>People Also Ask</h2>
" .
        "<p>These are common search questions potential buyers ask before deciding:</p>" .
        "<ul>" .
        "<li><strong>Is {$title} worth buying this year?</strong> It is a strong candidate for buyers who want a complete package with fewer compromises across comfort, tech, and ownership predictability.</li>" .
        "<li><strong>How does {$title} compare with competitors?</strong> The model typically wins by offering more balanced day-to-day behavior, even if some rivals lead in one isolated metric.</li>" .
        $chargingQuestion .
        "<li><strong>What should I check before signing the purchase?</strong> Compare trim value, warranty clarity, service network quality, and total cost of ownership rather than focusing only on sticker price.</li>" .
        "</ul>
";
}

function buildFaqSchemaScript($title, $isEV) {
    $faqItems = [
        [
            'question' => "Is {$title} a good daily driver?",
            'answer' => "Yes. {$title} is tuned to balance comfort, performance, and practical ownership, making it a solid daily-use option for most buyers.",
        ],
        [
            'question' => "How does {$title} compare with competitors?",
            'answer' => "It usually stands out through better overall balance and ownership confidence rather than relying on a single headline metric.",
        ],
        [
            'question' => $isEV ? "Is {$title} practical for charging routines?" : "Is {$title} economical to run over time?",
            'answer' => $isEV
                ? "With suitable home or public charging access, it can be practical for daily routines while also reducing long-term running costs."
                : "When maintained well and matched with the right trim, it can deliver predictable ownership costs over the long term.",
        ],
    ];

    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'FAQPage',
        'mainEntity' => array_map(function ($item) {
            return [
                '@type' => 'Question',
                'name' => $item['question'],
                'acceptedAnswer' => [
                    '@type' => 'Answer',
                    'text' => $item['answer'],
                ],
            ];
        }, $faqItems),
    ];

    return "<script type='application/ld+json'>" . json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "</script>";
}

function ensureMinimumWordCount($html, $title, $minimumWords = 2100, array $nicheMeta = []) {
    $expansionLibrary = getArticleExpansionLibrary($title, $nicheMeta);

    $currentWords = str_word_count(strip_tags($html));
    $i = 0;
    while ($currentWords < $minimumWords) {
        $html .= "\n" . $expansionLibrary[$i % count($expansionLibrary)];
        $currentWords = str_word_count(strip_tags($html));
        $i++;
    }

    return $html;
}

function buildSeoBlock($title, $excerpt, array $nicheMeta = []) {
    $keywords = buildNicheSeoKeywords($title, $nicheMeta);
    $metaDescription = mb_substr(trim((string)$excerpt), 0, 155);
    $keywordHtml = '<ul><li>' . implode('</li><li>', array_map('e', $keywords)) . '</li></ul>';
    $categoryLabel = trim((string)$nicheMeta['label']);
    $pageLabel = $categoryLabel !== '' ? $categoryLabel : 'Buyer Guide';

    return [
        'meta_title' => $title . ' | ' . $pageLabel,
        'meta_description' => $metaDescription,
        'keywords' => $keywords,
        'html_block' => "<section class='seo-optimization'><h2>SEO Focus Keywords</h2>{$keywordHtml}<p><strong>Meta Description:</strong> " . e($metaDescription) . "</p></section>",
    ];
}

function buildArticleExportHtml(array $payload) {
    $baseUrl = getSiteBaseUrl();
    $siteTitle = getSiteTitle();
    $title = trim((string)($payload['title'] ?? ''));
    $slug = trim((string)($payload['slug'] ?? ''));
    $excerpt = trim((string)($payload['excerpt'] ?? ''));
    $content = (string)($payload['content'] ?? '');
    $published = trim((string)($payload['published_at'] ?? ''));
    $category = trim((string)($payload['category'] ?? ''));

    $pageTitle = $title !== '' ? $title . ' | ' . $siteTitle : $siteTitle;
    $pageDescription = $excerpt !== '' ? $excerpt : mb_substr(strip_tags($content), 0, 160);
    $canonical = rtrim($baseUrl, '/') . '/index.php?slug=' . rawurlencode($slug);

    $ogImage = trim((string)($payload['image'] ?? '')) ?: trim((string)($payload['image2'] ?? ''));
    $ogImageTag = $ogImage !== '' ? "<meta property=\"og:image\" content=\"" . e($ogImage) . "\">" : '';

    $html = '<!DOCTYPE html>\n';
    $html .= '<html lang="en">\n';
    $html .= '<head>\n';
    $html .= '    <meta charset="UTF-8">\n';
    $html .= '    <title>' . e($pageTitle) . '</title>\n';
    $html .= '    <meta name="description" content="' . e($pageDescription) . '">\n';
    $html .= '    <link rel="canonical" href="' . e($canonical) . '">\n';
    $html .= '    <meta property="og:title" content="' . e($pageTitle) . '">\n';
    $html .= '    <meta property="og:description" content="' . e($pageDescription) . '">\n';
    if ($ogImageTag) {
        $html .= '    ' . $ogImageTag . "\n";
    }
    $html .= '</head>\n';
    $html .= '<body>\n';
    $html .= '<article>\n';
    $html .= '<h1>' . e($title) . '</h1>\n';
    if ($published !== '') {
        $html .= '<time datetime="' . e($published) . '">' . e($published) . '</time>\n';
    }
    if ($category !== '') {
        $html .= '<p><strong>Category:</strong> ' . e($category) . '</p>\n';
    }
    $html .= $content . '\n';
    $html .= '</article>\n';
    $html .= '</body>\n';
    $html .= '</html>\n';

    return $html;
}

function writeArticleExportFiles($articleId, $slug, array $payload) {
    $exportsDir = __DIR__ . '/../data/exports';
    if (!is_dir($exportsDir)) {
        mkdir($exportsDir, 0777, true);
    }

    $htmlPath = $exportsDir . '/' . $slug . '.html';
    $jsonPath = $exportsDir . '/' . $slug . '.json';

    $htmlContent = buildArticleExportHtml($payload);
    file_put_contents($htmlPath, $htmlContent);
    file_put_contents($jsonPath, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    $pdo = db_connect();
    $stmt = $pdo->prepare("INSERT INTO article_exports (article_id, slug, html_path, json_path, created_at)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(article_id) DO UPDATE SET
            slug = excluded.slug,
            html_path = excluded.html_path,
            json_path = excluded.json_path,
            created_at = excluded.created_at");
    $stmt->execute([(int)$articleId, $slug, 'data/exports/' . $slug . '.html', 'data/exports/' . $slug . '.json', date('Y-m-d H:i:s')]);
}

function getStaticPages($language = null) {
    if ($language === null) {
        $language = detectPreferredLanguage();
    }
    $isArabic = $language === 'ar';
    $nicheServicesContent = [];
    $niches = listNiches();
    foreach ($niches as $niche) {
        $nicheName = trim((string)($niche['name'] ?? ''));
        $nicheSlug = trim((string)($niche['slug'] ?? ''));
        $nicheDesc = trim((string)($niche['description'] ?? ''));
        if ($nicheName === '') {
            continue;
        }

        $rssSources = $nicheSlug !== '' ? getNicheRssSources($nicheSlug) : [];
        $webSources = $nicheSlug !== '' ? getNicheWebSources($nicheSlug) : [];
        $rssCount = count($rssSources);
        $webCount = count($webSources);
        $sampleRss = $rssCount > 0 ? (string)$rssSources[0] : '';
        $sampleWeb = $webCount > 0 ? (string)$webSources[0] : '';
        $nicheTitle = $nicheName . ($nicheSlug !== '' ? ' (' . $nicheSlug . ')' : '');

        if ($isArabic) {
            $nicheServicesContent[] = 'نيش "' . $nicheTitle . '": نوفّر له إطار عمل متكامل للنمو يشمل التخطيط التحريري، تحسين الظهور في البحث، وقياس النتائج.';
            $nicheServicesContent[] = 'الوصف: ' . ($nicheDesc !== '' ? $nicheDesc : 'لا يوجد وصف حاليًا، ويمكننا صياغة وصف احترافي موجّه بدقة للجمهور المستهدف.');
            $nicheServicesContent[] = 'الجاهزية الحالية للمصادر: RSS=' . $rssCount . ' | Web=' . $webCount . '.';
            $nicheServicesContent[] = $sampleRss !== '' ? 'أقوى مصدر RSS مقترح: ' . $sampleRss : 'لا يوجد مصدر RSS مضاف حاليًا.';
            $nicheServicesContent[] = $sampleWeb !== '' ? 'أقوى مصدر Web مقترح: ' . $sampleWeb : 'لا يوجد مصدر Web مضاف حاليًا.';
            $nicheServicesContent[] = 'خطة AF (Attract & Follow-up): جذب الزوار عبر مواضيع دقيقة، ثم متابعة الأداء أسبوعيًا لتطوير خطة المحتوى وتحسين التحويل.';
        } else {
            $nicheServicesContent[] = 'Niche "' . $nicheTitle . '": we provide a complete growth framework across editorial planning, search visibility optimization, and measurable performance tracking.';
            $nicheServicesContent[] = 'Description: ' . ($nicheDesc !== '' ? $nicheDesc : 'No description is configured yet; we can craft a focused, audience-specific positioning summary.');
            $nicheServicesContent[] = 'Current source readiness: RSS=' . $rssCount . ' | Web=' . $webCount . '.';
            $nicheServicesContent[] = $sampleRss !== '' ? 'Top suggested RSS source: ' . $sampleRss : 'No RSS source is currently configured.';
            $nicheServicesContent[] = $sampleWeb !== '' ? 'Top suggested Web source: ' . $sampleWeb : 'No Web source is currently configured.';
            $nicheServicesContent[] = 'AF plan (Attract & Follow-up): attract qualified traffic through precise topic clusters, then run weekly follow-up optimization to improve reach and conversion.';
        }
    }
    if (empty($nicheServicesContent)) {
        $nicheServicesContent = $isArabic
            ? ['نقدّم خدمات مرنة قابلة للتخصيص حسب النيش المستهدف مع متابعة وتحسين مستمر.']
            : ['We offer flexible, niche-specific services with continuous follow-up and optimization.'];
    }
    return [
        'about' => [
            'title' => $isArabic ? 'من نحن' : 'About Us',
            'description' => $isArabic
                ? 'تعرف على رسالتنا التحريرية في مجال السيارات ومعايير النشر التي نعتمدها.'
                : 'Learn more about our automotive editorial mission, publishing standards, and audience-first approach.',
            'content' => $isArabic
                ? [
                    'ننشر محتوى عمليًا عن السيارات يركز على أسئلة المالك الحقيقية مثل الصيانة والشراء والسلامة.',
                    'نجمع بين الأتمتة والمراجعة البشرية لضمان جودة المحتوى وسهولة القراءة.',
                    'نلتزم بالوضوح والشفافية لمساعدة القرّاء على اتخاذ قرارات أفضل.',
                ]
                : [
                    'We publish practical automotive content focused on real ownership questions: maintenance, buying, safety, and long-term value.',
                    'Our editorial workflow combines automated research with final quality checks for readability, originality, and user usefulness.',
                    'We prioritize clear language, transparent labeling, and content that helps readers make better car decisions.',
                ],
        ],
        'contact' => [
            'title' => $isArabic ? 'تواصل معنا' : 'Contact Us',
            'description' => $isArabic
                ? 'هل تحتاج دعمًا أو ترغب في التعاون؟ تواصل مع فريق التحرير والدعم.'
                : 'Need support, want to report an issue, or discuss collaboration? Reach our editorial and support team.',
            'content' => $isArabic
                ? [
                    'لدعم الموقع وطلبات التحرير: contact@example.com',
                    'للشراكات والإعلانات: partnerships@example.com',
                    'نراجع جميع الرسائل ونحاول الرد خلال يومي عمل.',
                ]
                : [
                    'For support and editorial requests, please email: contact@example.com',
                    'For ad and business inquiries, please email: partnerships@example.com',
                    'We review all messages and aim to reply within 2 business days.',
                ],
        ],
        'services' => [
            'title' => $isArabic ? 'خدماتنا' : 'Our Services',
            'description' => $isArabic
                ? 'نقدم حزمة خدمات سيارات متكاملة تشمل الاستشارات قبل الشراء، تحليل التكلفة، وخطط الصيانة الذكية.'
                : 'Explore our end-to-end automotive services, from pre-purchase consulting to maintenance planning and ownership optimization.',
            'content' => array_merge(
                $isArabic
                ? [
                    'نقدّم خدمة استشارات قبل الشراء لمساعدتك على اختيار السيارة المناسبة بناءً على نمط الاستخدام اليومي، ميزانية الوقود أو الشحن، وتكاليف الملكية المتوقعة خلال 3 إلى 5 سنوات.',
                    'فريقنا يجهّز مقارنة تفصيلية بين الفئات المختلفة لنفس الموديل، مع توضيح الفرق الحقيقي في التجهيزات، أنظمة الأمان، القيمة مقابل السعر، وإعادة البيع المتوقعة في سوق المستعمل.',
                    'نوفر خدمة مراجعة حالة السيارة المستعملة قبل الشراء عبر قائمة فحص عملية تشمل السجل الفني، حالة الهيكل، أداء المحرك أو البطارية، وتكاليف الإصلاح المحتملة بعد الاستلام.',
                    'نساعدك في بناء خطة صيانة دورية ذكية مرتبطة بعدد الكيلومترات وطبيعة القيادة داخل المدينة أو على الطرق السريعة، لتقليل الأعطال المفاجئة وتحسين عمر السيارة.',
                    'نقدم تحليلات تكلفة تشغيل شهرية تتضمن الوقود أو الكهرباء، التأمين، الإهلاك، رسوم الترخيص، وتوقعات الصيانة، بحيث تحصل على صورة مالية واضحة قبل أي قرار.',
                    'للشركات وأصحاب الأسطول الصغيرة، نوفر خدمة تحسين إدارة الأسطول عبر تقارير أداء المركبات، توزيع الاستخدام، وتحديد فرص خفض التكلفة ورفع الكفاءة التشغيلية.',
                    'نوفر خدمة تخطيط الرحلات الطويلة للسيارات الكهربائية والبنزين مع توصيات عملية لنقاط التوقف، إدارة الاستهلاك، وتجهيزات السلامة الضرورية قبل السفر.',
                    'نشاركك أدلة مبسطة للعناية بالسيارة بعد الشراء، مثل حماية الطلاء، متابعة ضغط الإطارات، تحسين استهلاك الطاقة، والحفاظ على القيمة السوقية للسيارة مع الوقت.',
                ]
                : [
                    'Our pre-purchase advisory service helps you choose the right vehicle using daily driving patterns, fuel or charging realities, and projected 3–5 year ownership costs.',
                    'We provide detailed trim-level comparisons to highlight meaningful differences in safety features, technology, comfort, resale potential, and true value for money.',
                    'For used vehicles, we offer a practical inspection framework covering service history, body condition, engine or battery health, and likely near-term repair risks.',
                    'We design mileage-based maintenance roadmaps tailored to city and highway usage so you can reduce unexpected failures and extend long-term vehicle reliability.',
                    'Our ownership cost analysis includes fuel or electricity, insurance, depreciation, licensing fees, and forecast maintenance to give you a complete financial view.',
                    'For small fleets and business operators, we provide optimization guidance through usage analytics, vehicle allocation insights, and cost-efficiency opportunities.',
                    'We support long-distance trip planning for EV and ICE vehicles with practical stop strategy recommendations, range management tips, and safety preparation checklists.',
                    'You also get easy-to-follow post-purchase care guidance covering tire pressure habits, paint protection basics, efficiency practices, and resale value preservation.',
                ],
                $nicheServicesContent
            ),
        ],
        'privacy' => [
            'title' => $isArabic ? 'سياسة الخصوصية' : 'Privacy Policy',
            'description' => $isArabic
                ? 'اعرف كيف نجمع ونستخدم ونحمي بيانات الزوار وملفات تعريف الارتباط.'
                : 'Read how we collect, use, and protect visitor data, cookies, and analytics information.',
            'content' => $isArabic
                ? [
                    'قد نستخدم التحليلات وتقنيات الإعلانات (مثل الكوكيز) لفهم الزيارات وتحسين التجربة.',
                    'لا نجمع عمدًا بيانات شخصية حساسة عبر الصفحات العامة، ونستخدم بيانات التواصل للرد فقط.',
                    'قد تعالج خدمات الطرف الثالث البيانات وفق سياساتها الخاصة، ويمكنك تعطيل الكوكيز من إعدادات المتصفح.',
                ]
                : [
                    'We may use analytics and advertising technologies (such as cookies and measurement scripts) to understand traffic and improve user experience.',
                    'We do not intentionally collect sensitive personal information through public pages. If you contact us directly, we only use your information to respond.',
                    'Third-party services (including ad providers) may process data according to their own privacy policies. You can disable cookies from your browser settings.',
                ],
        ],
        'terms' => [
            'title' => $isArabic ? 'الشروط والأحكام' : 'Terms of Use',
            'description' => $isArabic
                ? 'شروط الاستخدام التي تغطي الاستخدام المقبول وحقوق الملكية والتنبيهات القانونية.'
                : 'Website terms covering acceptable use, intellectual property, disclaimers, and content usage.',
            'content' => $isArabic
                ? [
                    'باستخدامك للموقع فإنك توافق على استخدام المحتوى لأغراض قانونية ومعلوماتية شخصية فقط.',
                    'جميع المقالات لأغراض معرفية عامة ولا تُعد بديلاً عن الاستشارات المهنية.',
                    'قد نقوم بتحديث المحتوى والسياسات في أي وقت لضمان الجودة والامتثال.',
                ]
                : [
                    'By using this website, you agree to use the content for lawful and personal informational purposes only.',
                    'All articles are provided for general information and do not replace professional legal, financial, or mechanical advice.',
                    'We may update content and site policies at any time to maintain quality, compliance, and platform requirements.',
                ],
        ],
    ];
}

function buildHeadingAnchorId($text, $fallback = 'section') {
    $base = strtolower(trim((string)$text));
    $base = preg_replace('/[^a-z0-9\s-]/', '', $base);
    $base = preg_replace('/\s+/', '-', (string)$base);
    $base = trim((string)$base, '-');
    if ($base === '') {
        $base = trim((string)$fallback);
    }
    return $base;
}

function buildArticleTableOfContents(array $sections) {
    if (!$sections) {
        return '';
    }

    $items = [];
    foreach ($sections as $section) {
        $title = trim((string)($section['title'] ?? ''));
        $id = trim((string)($section['id'] ?? ''));
        if ($title === '' || $id === '') {
            continue;
        }
        $items[] = "<li><a href='#" . e($id) . "'>" . e($title) . "</a></li>";
    }

    if (!$items) {
        return '';
    }

    return "<section class='article-toc'><h2>Quick Navigation</h2><ol>" . implode('', $items) . "</ol></section>";
}

function generateArticle($title) {
    $title = cleanAndNormalizeTitle($title);
    if ($title === '') {
        $title = 'New Release Review';
    }

    $activeNicheSlug = getActiveNicheSlug();
    $nicheMeta = getNicheArticleMeta($activeNicheSlug);
    $nicheType = getNicheContentType($nicheMeta);
    $model = trim(preg_replace('/\b(202[0-9]|20[0-9]{2})\b/', '', $title));
    $isEV = stripos($title, 'EV') !== false || stripos($title, 'electric') !== false || str_contains(mb_strtolower($nicheMeta['slug'], 'UTF-8'), 'ev');
    $bodyType = classifyVehicleProfile($title);
    if ($nicheType !== 'auto') {
        $bodyType = ucfirst($nicheType);
    }
    $topicContext = trim((string)$nicheMeta['intro_context']);
    if ($topicContext === '') {
        $topicContext = 'audience expectations, topical relevance, and niche-specific value';
    }

    $content = "<h1>" . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . "</h1>\n";
    $content .= "<p class='text-muted'>Published " . date('F j, Y') . " • " . htmlspecialchars($nicheMeta['label'], ENT_QUOTES, 'UTF-8') . "</p>\n";
    $coverImage = buildUniqueArticleImageUrl($title, $model);
    $imageAltSuffix = trim((string)getSetting('seo_image_alt_suffix', ' - car image'));
    $imageTitleSuffix = trim((string)getSetting('seo_image_title_suffix', ' - photo'));
    $imageAlt = trim($title . ' ' . ltrim($imageAltSuffix, '- '));
    $imageTitle = trim($title . ' ' . ltrim($imageTitleSuffix, '- '));
    $content .= "<img src='" . htmlspecialchars($coverImage, ENT_QUOTES, 'UTF-8') . "' class='img-fluid rounded mb-4' alt='" . htmlspecialchars($imageAlt, ENT_QUOTES, 'UTF-8') . "' title='" . htmlspecialchars($imageTitle, ENT_QUOTES, 'UTF-8') . "' loading='eager' decoding='async' fetchpriority='high'>\n";
    $content .= "<p>" . getRandomIntro($title, $nicheMeta) . " This review follows an editorial structure designed to deliver deep analysis, clear comparisons, and practical buying guidance.</p>\n";
    $content .= "<p>The article is written for " . htmlspecialchars($nicheMeta['label'], ENT_QUOTES, 'UTF-8') . " readers and focuses on " . htmlspecialchars($topicContext, ENT_QUOTES, 'UTF-8') . " to make the decision easier for people who want more than surface-level advice.</p>\n";
    $content .= "<p>This {$title} review is optimized to answer the top buyer questions around " . htmlspecialchars($topicContext, ENT_QUOTES, 'UTF-8') . ".</p>\n";
    $content .= "<p><strong>Quick Take:</strong> The {$title} is a {$bodyType}-class product focused on balanced performance, everyday usability, and ownership predictability rather than one-dimensional headline metrics.</p>\n";
    $content .= "<p>We evaluate it with a focus on " . htmlspecialchars(getNicheWritingAngle($nicheMeta), ENT_QUOTES, 'UTF-8') . ", so the coverage stays aligned with the most meaningful buying signals for this niche.</p>\n";
    $content .= "<h2>What You Will Learn in This Guide</h2>\n";
    $content .= "<ul><li>How {$title} performs in real ownership conditions, not only in launch marketing.</li><li>Which trim strategy makes the most financial sense for different buyer types.</li><li>Where {$title} stands versus competitors in comfort, tech, efficiency, and long-term value.</li></ul>\n";

    $sections = array_merge(getNicheSections($nicheType), [
        'Technology Stack, Infotainment, and Connectivity Experience' => [
            'interface speed, readability, and cognitive simplicity',
            'smartphone integration and navigation reliability in practice',
            'software maturity, update path, and feature longevity'
        ],
        'Safety Systems, Driver Assistance, and Durability Outlook' => [
            'calibration quality of active safety interventions',
            'passive safety confidence and structural reassurance',
            'maintenance predictability and long-term reliability perception'
        ],
        'Ownership Economics, Trim Strategy, and Buyer Recommendations' => [
            'cost of ownership across fuel or charging, service, and insurance',
            'which configuration levels provide the strongest value density',
            'how to shortlist based on real priorities rather than hype'
        ]
    ]);

    $tocSections = [];
    foreach ($sections as $sectionTitle => $focusPoints) {
        $sectionId = buildHeadingAnchorId($sectionTitle, 'section-' . (count($tocSections) + 1));
        $tocSections[] = ['title' => $sectionTitle, 'id' => $sectionId];
        $content .= "<h2 id='" . e($sectionId) . "'>" . $sectionTitle . "</h2>\n";
        foreach (buildSectionContent($title, $sectionTitle, $focusPoints, $nicheType, $nicheMeta) as $paragraph) {
            $content .= $paragraph . "\n";
        }
    }

    $content = preg_replace('/(<h2>What You Will Learn in This Guide<\/h2>\n<ul>.*?<\/ul>\n)/s', "$1" . buildArticleTableOfContents($tocSections) . "\n", $content, 1);

    $horsepower = rand(260, 640);
    $zeroToSixty = number_format(rand(34, 67) / 10, 1);
    $efficiencyLine = $isEV
        ? rand(420, 680) . ' km estimated range (mixed use)'
        : rand(6, 11) . ' L/100km combined estimate';
    $drivetrain = $isEV ? 'Dual Electric Motors (AWD)' : '2.5L Turbo + Advanced Automatic Transmission';

    $content .= "<h2>Technical Snapshot</h2>\n";
    $content .= "<table class='table table-bordered'><tr><th>Powertrain</th><td>{$drivetrain}</td></tr><tr><th>Output</th><td>{$horsepower} hp</td></tr><tr><th>0-60 mph</th><td>{$zeroToSixty} seconds</td></tr><tr><th>Efficiency</th><td>{$efficiencyLine}</td></tr><tr><th>Editorial Category</th><td>" . htmlspecialchars($nicheMeta['category'], ENT_QUOTES, 'UTF-8') . "</td></tr></table>\n";

    $content .= buildComparisonTable($title, $bodyType, $isEV);
    $content .= buildBuyerPersonaSection($title, $isEV, $bodyType);
    $content .= "<h2>Strengths and Trade-Offs</h2>\n";
    $content .= "<ul><li><strong>Strengths:</strong> Cohesive engineering balance, strong day-to-day usability, mature technology integration, and a clear long-term value narrative.</li><li><strong>Trade-Offs:</strong> Higher entry price in premium trims, optional packages that may overlap in features, and availability pressure in high-demand regions.</li></ul>\n";
    $content .= buildFaqSection($title, $isEV);
    $content .= buildPeopleAlsoAskSection($title, $isEV);
    $content .= buildBuyingChecklistSection($title, $isEV);
    $content .= "<h2>Final Editorial Verdict</h2>\n";
    $content .= "<p class='mt-3'>The {$title} succeeds because it behaves like a complete product, not a collection of isolated features. It combines emotional appeal with practical intelligence, and that combination is exactly what modern buyers need in an uncertain, fast-evolving market. If your priority is a vehicle that remains convincing beyond launch-week excitement, this model is a serious and well-justified candidate.</p>";

    $minimumWords = getSettingInt('min_words', 3000, 1200, 300000);
    $content = ensureMinimumWordCount($content, $title, $minimumWords, $nicheMeta);

    $plainText = trim(strip_tags($content));
    $excerpt = mb_substr($plainText, 0, 340);
    if (mb_strlen($plainText) > 340) {
        $excerpt .= '...';
    }

    $seo = buildSeoBlock($title, $excerpt, $nicheMeta);
    $content .= "\n" . $seo['html_block'];
    $content .= "\n" . buildFaqSchemaScript($title, $isEV);

    return [
        'content' => $content,
        'excerpt' => $excerpt,
        'image' => $coverImage,
        'meta_title' => $seo['meta_title'],
        'meta_description' => $seo['meta_description'],
        'focus_keywords' => $seo['keywords'],
    ];
}

function isSqliteLockedException(PDOException $exception) {
    $message = mb_strtolower($exception->getMessage(), 'UTF-8');
    return strpos($message, 'database is locked') !== false || strpos($message, 'database table is locked') !== false;
}

function executeStatementWithRetry(PDOStatement $statement, array $params, $maxAttempts = 5, $initialDelayMs = 100) {
    $attempt = 0;
    $delayMs = max(1, (int)$initialDelayMs);
    $limit = max(1, (int)$maxAttempts);

    while (true) {
        try {
            $statement->execute($params);
            return;
        } catch (PDOException $exception) {
            $attempt++;
            if ($attempt >= $limit || !isSqliteLockedException($exception)) {
                throw $exception;
            }
            usleep($delayMs * 1000);
            $delayMs *= 2;
        }
    }
}

function pingSearchEngines($sitemapUrl) {
    $sitemapUrl = trim((string)$sitemapUrl);
    if ($sitemapUrl === '') {
        return false;
    }
    $targets = [
        'https://www.google.com/ping?sitemap=' . rawurlencode($sitemapUrl),
        'https://www.bing.com/ping?sitemap=' . rawurlencode($sitemapUrl),
    ];
    foreach ($targets as $u) {
        @file_get_contents($u);
    }
    return true;
}

function updateRobotsTxt() {
    $base = getSiteBaseUrl();
    if ($base === '') return false;
    $content = "User-agent: *\nAllow: /\n\n";
    $content .= "Sitemap: " . rtrim($base, '/') . "/sitemap.php\n";
    @file_put_contents(__DIR__ . '/../robots.txt', $content);
    return true;
}

function saveArticle($title, $data) {
    if (isDuplicateArticlePayload($title, $data['content'] ?? '')) {
        return false;
    }

    $pdo = db_connect();
    $slug = generateUniqueSlug($title);
    $nicheId = getActiveNicheId();

    $autoTranslate = getSettingInt('auto_translate_enabled', 0, 0, 1) === 1;
    $targetLang = trim((string)getSetting('auto_translate_target_language', ''));
    $translatedTitle = null;
    $translatedContent = null;
    $origLanguage = '';

    if ($autoTranslate && $targetLang !== '') {
        $translatedTitle = translateText($title, $targetLang);
        $translatedContent = translateText($data['content'] ?? '', $targetLang);
        $origLanguage = $targetLang;
    }

    $nicheMeta = getNicheArticleMeta();
    $category = trim((string)$nicheMeta['category']);
    if ($category === '') {
        $category = 'News';
    }

    $stmt = $pdo->prepare("INSERT INTO articles (title, slug, content, image, image2, excerpt, published_at, category, niche_id, translated_title, translated_content, orig_language) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
    executeStatementWithRetry($stmt, [
        $title,
        $slug,
        $data['content'],
        $data['image'] ?? null,
        $data['image2'] ?? null,
        $data['excerpt'] ?? null,
        date('Y-m-d H:i:s'),
        $category,
        $nicheId,
        $translatedTitle,
        $translatedContent,
        $origLanguage
    ]);
    $articleId = (int)$pdo->lastInsertId();

    initArticleStats($articleId);

    $tags = generateAutoTags($title, $data['content'] ?? '');
    foreach ($tags as $tag) {
        addTagToArticle($articleId, $tag);
    }

    writeArticleExportFiles($articleId, $slug, [
        'id' => $articleId,
        'title' => $title,
        'slug' => $slug,
        'content' => $data['content'],
        'excerpt' => $data['excerpt'],
        'image' => $data['image'] ?? null,
        'image2' => $data['image2'] ?? null,
        'translated_title' => $translatedTitle,
        'translated_content' => $translatedContent,
        'meta_title' => $data['meta_title'] ?? null,
        'meta_description' => $data['meta_description'] ?? null,
        'focus_keywords' => $data['focus_keywords'] ?? [],
        'published_at' => date('c'),
    ]);

    pingSearchEngines(getSiteBaseUrl() . '/sitemap.php');

    return true;
}

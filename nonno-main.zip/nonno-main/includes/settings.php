<?php

function getSetting($key, $default = null) {
    $pdo = db_connect();
    $stmt = $pdo->prepare("SELECT value FROM settings WHERE key = ? LIMIT 1");
    $stmt->execute([$key]);
    $value = $stmt->fetchColumn();
    return $value !== false ? $value : $default;
}

function setSetting($key, $value) {
    $pdo = db_connect();
    $stmt = $pdo->prepare("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value");
    executeStatementWithRetry($stmt, [$key, (string)$value]);
}

function getSettingInt($key, $default = 0, $min = null, $max = null) {
    $value = (int)getSetting($key, (string)$default);
    if ($min !== null) {
        $value = max((int)$min, $value);
    }
    if ($max !== null) {
        $value = min((int)$max, $value);
    }
    return $value;
}

function getAdSettings() {
    $mode = trim((string)getSetting('ads_injection_mode', 'smart'));
    if (!in_array($mode, ['smart', 'interval'], true)) {
        $mode = 'smart';
    }

    $label = trim((string)getSetting('ads_label_text', 'Sponsored'));
    if ($label === '') {
        $label = 'Sponsored';
    }

    return [
        'enabled' => getSettingInt('ads_enabled', 0, 0, 1) === 1,
        'mode' => $mode,
        'paragraph_interval' => getSettingInt('ads_paragraph_interval', 4, 2, 10),
        'max_units' => getSettingInt('ads_max_units_per_article', 2, 1, 6),
        'min_words_before_first' => getSettingInt('ads_min_words_before_first_injection', 260, 120, 900),
        'min_article_words' => getSettingInt('ads_min_article_words', 420, 120, 3000),
        'blocked_title_keywords' => trim((string)getSetting('ads_blocked_title_keywords', '')),
        'blocked_categories' => trim((string)getSetting('ads_blocked_categories', '')),
        'label' => mb_substr($label, 0, 40),
        'html_code' => trim((string)getSetting('ads_html_code', '<div class="ad-unit-inner">Place your ad code here</div>')),
    ];
}

function parseAdListTokens($value) {
    $raw = preg_split('/[,\n]+/u', (string)$value);
    $keywords = [];
    foreach ($raw as $item) {
        $token = mb_strtolower(trim((string)$item));
        if ($token === '' || mb_strlen($token) < 2) {
            continue;
        }
        $keywords[$token] = true;
    }

    return array_keys($keywords);
}

function parseAdBlockedTitleKeywords($value) {
    return parseAdListTokens($value);
}

function countVisibleWords($text) {
    $text = trim((string)$text);
    if ($text === '') {
        return 0;
    }

    if (preg_match_all('/[\p{L}\p{N}]+/u', $text, $matches)) {
        return count($matches[0]);
    }

    return str_word_count($text);
}

function getAutoPublishIntervalSeconds() {
    $secondsRaw = getSetting('auto_publish_interval_seconds', null);
    if ($secondsRaw !== null && $secondsRaw !== '') {
        return getSettingInt('auto_publish_interval_seconds', 10800, 1, PHP_INT_MAX);
    }

    $minutesRaw = getSetting('auto_publish_interval_minutes', null);
    if ($minutesRaw !== null && $minutesRaw !== '') {
        $minutes = getSettingInt('auto_publish_interval_minutes', 180, 1, PHP_INT_MAX);
        if ($minutes > intdiv(PHP_INT_MAX, 60)) {
            return PHP_INT_MAX;
        }

        return max(1, $minutes * 60);
    }

    return 10800;
}

function getCurrentBaseUrl() {
    $forwardedProto = trim((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''));
    $isHttps = $forwardedProto !== ''
        ? strtolower($forwardedProto) === 'https'
        : ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ((int)($_SERVER['SERVER_PORT'] ?? 80) === 443));

    $scheme = $isHttps ? 'https' : 'http';
    $host = trim((string)($_SERVER['HTTP_HOST'] ?? 'localhost'));

    $scriptName = trim((string)($_SERVER['SCRIPT_NAME'] ?? ''));
    $basePath = str_replace('\\', '/', dirname($scriptName));
    if ($basePath === '.' || $basePath === '/') {
        $basePath = '';
    }
    $basePath = rtrim($basePath, '/');

    return $scheme . '://' . $host . $basePath;
}

function getCronEndpointUrl() {
    return getCurrentBaseUrl() . '/cron.php';
}

function getAutoPublishSchedulerMeta() {
    $lastRun = strtotime((string)getSetting('auto_publish_last_run_at', '1970-01-01 00:00:00')) ?: 0;
    $interval = getAutoPublishIntervalSeconds();
    $nextRun = $lastRun + $interval;
    $remaining = max(0, $nextRun - time());

    return [
        'interval_seconds' => $interval,
        'last_run_at' => date('Y-m-d H:i:s', $lastRun),
        'next_run_at' => date('Y-m-d H:i:s', $nextRun),
        'remaining_seconds' => $remaining,
    ];
}

function getSiteTitle() {
    $configuredTitle = trim((string)getSetting('site_title', SITE_TITLE));
    return $configuredTitle !== '' ? $configuredTitle : SITE_TITLE;
}

function getSiteBaseUrl() {
    $host = trim((string)($_SERVER['HTTP_HOST'] ?? ''));
    if ($host === '') {
        return '';
    }

    $https = strtolower((string)($_SERVER['HTTPS'] ?? ''));
    $forwardedProto = strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''));
    $scheme = ($https === 'on' || $https === '1' || $forwardedProto === 'https') ? 'https' : 'http';

    return $scheme . '://' . $host;
}

<?php

function fetchUrlBody($url, $timeoutSeconds = null) {
    $url = trim((string)$url);
    if ($url === '') {
        return null;
    }

    $cacheHit = getCachedUrlBody($url);
    if ($cacheHit !== null) {
        return $cacheHit;
    }

    $timeoutSeconds = $timeoutSeconds === null
        ? getSettingInt('fetch_timeout_seconds', 12, 3, 45)
        : max(1, (int)$timeoutSeconds);

    $retryAttempts = getSettingInt('fetch_retry_attempts', 3, 1, 5);
    $backoffMs = getSettingInt('fetch_retry_backoff_ms', 350, 100, 3000);

    for ($attempt = 1; $attempt <= $retryAttempts; $attempt++) {
        $context = stream_context_create([
            'http' => [
                'timeout' => $timeoutSeconds,
                'ignore_errors' => true,
                'user_agent' => getFetcherUserAgent(),
            ],
            'ssl' => [
                'verify_peer' => true,
                'verify_peer_name' => true,
            ],
        ]);

        $body = @file_get_contents($url, false, $context);
        $statusCode = extractHttpStatusCode($http_response_header ?? []);
        $ok = is_string($body) && $body !== '' && $statusCode >= 200 && $statusCode < 400;

        if ($ok) {
            cacheUrlBody($url, $body, $statusCode, true);
            return $body;
        }

        if ($attempt < $retryAttempts) {
            $jitterMs = random_int(0, 120);
            usleep(($backoffMs * $attempt + $jitterMs) * 1000);
        }
    }

    cacheUrlBody($url, is_string($body) ? $body : '', $statusCode, false);
    return null;
}

function getFetcherUserAgent() {
    $ua = trim((string)getSetting('fetch_user_agent', 'Mozilla/5.0 (compatible; VitoBot/1.0; +https://example.com/bot)'));
    return $ua !== '' ? $ua : 'Mozilla/5.0 (compatible; VitoBot/1.0; +https://example.com/bot)';
}

function extractHttpStatusCode(array $headers) {
    foreach ($headers as $headerLine) {
        if (preg_match('/^HTTP\/\d(?:\.\d)?\s+(\d{3})/i', (string)$headerLine, $matches)) {
            return (int)$matches[1];
        }
    }
    return 0;
}

function getUrlCacheTtlSeconds() {
    return getSettingInt('url_cache_ttl_seconds', 900, 60, 86400);
}

function getCachedUrlBody($url) {
    $pdo = db_connect();
    $stmt = $pdo->prepare('SELECT body, fetched_at, ttl_seconds, blocked_until FROM url_cache WHERE url = ? LIMIT 1');
    $stmt->execute([$url]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        return null;
    }

    $now = time();
    if ((int)$row['blocked_until'] > $now) {
        return null;
    }

    $ttl = max(60, (int)$row['ttl_seconds']);
    if (((int)$row['fetched_at'] + $ttl) < $now) {
        return null;
    }

    $body = (string)($row['body'] ?? '');
    return $body !== '' ? $body : null;
}

function cacheUrlBody($url, $body, $statusCode, $success) {
    $pdo = db_connect();
    $ttl = getUrlCacheTtlSeconds();
    $now = time();
    $statusCode = (int)$statusCode;

    $existingStmt = $pdo->prepare('SELECT fail_count FROM url_cache WHERE url = ? LIMIT 1');
    $existingStmt->execute([$url]);
    $existingFail = (int)$existingStmt->fetchColumn();

    $failCount = $success ? 0 : ($existingFail + 1);
    $blockedUntil = 0;
    if (!$success && ($statusCode === 429 || $statusCode === 403 || $failCount >= 3)) {
        $blockedUntil = $now + min(1800, 60 * $failCount);
    }

    $stmt = $pdo->prepare("INSERT INTO url_cache (url, body, status_code, fetched_at, ttl_seconds, fail_count, blocked_until)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(url) DO UPDATE SET
            body = excluded.body,
            status_code = excluded.status_code,
            fetched_at = excluded.fetched_at,
            ttl_seconds = excluded.ttl_seconds,
            fail_count = excluded.fail_count,
            blocked_until = excluded.blocked_until");

    $stmt->execute([$url, (string)$body, $statusCode, $now, $ttl, $failCount, $blockedUntil]);
}
